from __future__ import annotations
import numpy as np


def response_arrays(results):
    frequencies = np.array([r.frequency_hz for r in results], float)
    impedance = np.array([r.zin_ohm for r in results], complex)
    s11 = np.array([r.s11_db for r in results], float)
    vswr = np.array([r.vswr for r in results], float)
    return frequencies, impedance, s11, vswr


def spectral_target(results, zref=50.0):
    _, z, _, _ = response_arrays(results)
    zref = float(zref)
    return np.r_[z.real/zref, z.imag/zref]


def impedance_from_target(target, zref=50.0):
    target = np.asarray(target,float)
    n = len(target)//2
    return float(zref)*(target[:n]+1j*target[n:])


def objective_from_impedance(z, zref=50.0):
    z = np.asarray(z,complex)
    zref = float(zref)
    gamma = (z-zref)/(z+zref)
    mag = np.abs(gamma)
    center = len(z)//2
    return float(
        4.0*np.max(mag)
        + 1.0*np.mean(mag)
        + 0.18*np.mean(np.abs(z-zref)/zref)
        + 0.12*abs(z[center]-zref)/zref
    )


def objective_from_results(results):
    return objective_from_impedance(response_arrays(results)[1])


def band_metrics(results):
    f,z,s11,vswr=response_arrays(results)
    mask=(f>=2.400e9-1.0)&(f<=2.4835e9+1.0)
    if not np.any(mask):
        mask=np.ones_like(f,dtype=bool)
    center=int(np.argmin(np.abs(f-2.44175e9)))
    return {
        'worst_s11_db': float(np.max(s11[mask])),
        'best_s11_db': float(np.min(s11[mask])),
        'max_vswr': float(np.max(vswr[mask])),
        'center_frequency_hz': float(f[center]),
        'center_re_z_ohm': float(z[center].real),
        'center_im_z_ohm': float(z[center].imag),
        'center_s11_db': float(s11[center]),
        'objective': objective_from_impedance(z[mask]),
        'band_target_pass': bool(np.max(s11[mask]) <= -10.0),
    }
