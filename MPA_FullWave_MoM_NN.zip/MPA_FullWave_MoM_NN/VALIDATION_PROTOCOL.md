# Validation protocol may be:



Run:
python main.py --mode converge --profile standard



Then repeat the best design with progressively larger:

entire-domain mode sets;

radial quadrature orders;

angular spectral samples and/or

spectral cutoffs.

Report the result as converged only when the two finest independent settings satisfy approximately:

change in Re(Zin) < 2 Ohm

change in Im(Zin) < 2 Ohm

change in S11 < 0.3 dB or/and

resonance displacement < 10 MHz.



Finally, reproduce the delta-gap/terminal geometry consistently in ANSYS HFSS, then
replace it with the intended physical coax launch and report the difference.

