from __future__ import annotations
from dataclasses import replace
from pathlib import Path
import csv, json
import numpy as np

from dataset import clip_design, geometry_from_design
from metrics import objective_from_results, band_metrics, response_arrays
from mom.solver import SpectralMoMSolver


def perturb_design_and_config(design, cfg, rng):
    """Create one fabrication/material perturbation.

    The perturbation is explicitly evaluated with the full-wave spectral MoM.
    It is not a closed-form geometry/cavity approximation.
    """
    d = np.asarray(design, float).copy()
    tol = cfg.tolerance
    d[0] += rng.uniform(-tol.patch_length_tol_m, tol.patch_length_tol_m)
    d[1] += rng.uniform(-tol.patch_width_tol_m, tol.patch_width_tol_m)
    # d[2] is feed fraction. Convert feed-x tolerance into fraction tolerance.
    d[2] += rng.uniform(-tol.feed_x_tol_m, tol.feed_x_tol_m) / max(d[0], 1e-12)
    d[3] += rng.uniform(-tol.feed_y_tol_m, tol.feed_y_tol_m)
    d[4] += rng.uniform(-tol.terminal_span_tol_m, tol.terminal_span_tol_m)
    d = clip_design(d, cfg)

    material = replace(
        cfg.material,
        eps_r=max(1.0, cfg.material.eps_r + rng.uniform(-tol.eps_r_tol, tol.eps_r_tol)),
        substrate_h_m=max(0.2e-3, cfg.material.substrate_h_m + rng.uniform(-tol.substrate_h_tol_m, tol.substrate_h_tol_m)),
    )
    pcfg = replace(cfg, material=material)
    return d, pcfg


def evaluate_robustness(design, cfg, base_solver=None, samples=None, seed=None):
    """Monte-Carlo tolerance report using full-wave MoM for every sample."""
    if not cfg.tolerance.enabled:
        return {"enabled": False}
    n = int(cfg.tolerance.samples if samples is None else samples)
    rng = np.random.default_rng(cfg.tolerance.seed if seed is None else seed)
    records = []
    objectives = []
    worst_s11 = []

    # Include nominal point as sample 0.
    nominal_solver = base_solver if base_solver is not None else SpectralMoMSolver(cfg, cfg.sweep.synthesis_frequencies_hz)
    nominal_result = nominal_solver.sweep(geometry_from_design(design, cfg))
    nominal_obj = objective_from_results(nominal_result)
    nominal_metrics = band_metrics(nominal_result)
    objectives.append(nominal_obj)
    worst_s11.append(nominal_metrics["worst_s11_db"])
    records.append({
        "sample": 0,
        "type": "nominal",
        "objective": float(nominal_obj),
        "worst_s11_db": float(nominal_metrics["worst_s11_db"]),
        "center_re_z_ohm": float(nominal_metrics["center_re_z_ohm"]),
        "center_im_z_ohm": float(nominal_metrics["center_im_z_ohm"]),
        "eps_r": float(cfg.material.eps_r),
        "substrate_h_mm": float(cfg.material.substrate_h_m * 1e3),
        "design_si": np.asarray(design, float).tolist(),
    })

    for i in range(1, n + 1):
        pd, pcfg = perturb_design_and_config(design, cfg, rng)
        solver = SpectralMoMSolver(pcfg, pcfg.sweep.synthesis_frequencies_hz)
        result = solver.sweep(geometry_from_design(pd, pcfg))
        obj = objective_from_results(result)
        m = band_metrics(result)
        objectives.append(obj)
        worst_s11.append(m["worst_s11_db"])
        records.append({
            "sample": i,
            "type": "perturbed",
            "objective": float(obj),
            "worst_s11_db": float(m["worst_s11_db"]),
            "center_re_z_ohm": float(m["center_re_z_ohm"]),
            "center_im_z_ohm": float(m["center_im_z_ohm"]),
            "eps_r": float(pcfg.material.eps_r),
            "substrate_h_mm": float(pcfg.material.substrate_h_m * 1e3),
            "design_si": np.asarray(pd, float).tolist(),
        })

    objectives = np.asarray(objectives, float)
    worst_s11 = np.asarray(worst_s11, float)
    robust_score = float(np.mean(objectives) + cfg.tolerance.std_weight * np.std(objectives) + cfg.tolerance.worst_weight * np.max(objectives))
    pass_prob = float(np.mean(worst_s11 <= -10.0))
    return {
        "enabled": True,
        "samples_excluding_nominal": n,
        "objective_nominal": float(nominal_obj),
        "objective_mean": float(np.mean(objectives)),
        "objective_std": float(np.std(objectives)),
        "objective_worst": float(np.max(objectives)),
        "robust_score": robust_score,
        "worst_s11_mean_db": float(np.mean(worst_s11)),
        "worst_s11_worst_db": float(np.max(worst_s11)),
        "band_pass_probability": pass_prob,
        "records": records,
    }


def choose_robust_candidate(validated, cfg, solver):
    """Re-rank top nominal candidates by robust tolerance score."""
    if not cfg.tolerance.enabled or cfg.tolerance.samples <= 0:
        return validated[0][1], validated[0][2], validated[0][0], None, []
    n = min(len(validated), int(cfg.tolerance.robust_candidates))
    ranked = []
    for idx, (nominal_score, design, result) in enumerate(validated[:n], 1):
        report = evaluate_robustness(design, cfg, base_solver=solver)
        ranked.append((float(report["robust_score"]), nominal_score, design, result, report))
        print(
            f"robust candidate {idx:2d}/{n}: nominal={nominal_score:.5f} "
            f"robust={report['robust_score']:.5f} passP={report['band_pass_probability']:.2f}"
        )
    ranked.sort(key=lambda t: t[0])
    best_robust, best_nominal, best_design, best_result, best_report = ranked[0]
    return best_design, best_result, best_nominal, best_report, ranked


def save_robustness_report(report, ranked, outdir: str | Path):
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    if report is None:
        return
    public_report = {k: v for k, v in report.items() if k != "records"}
    (out / "robust_tolerance_summary.json").write_text(json.dumps(public_report, indent=2))
    with (out / "robust_tolerance_samples.csv").open("w", newline="") as h:
        records = report.get("records", [])
        if records:
            fields = [k for k in records[0].keys() if k != "design_si"] + ["patch_length_mm", "patch_width_mm", "feed_x_fraction", "feed_y_mm", "terminal_span_y_mm"]
            writer = csv.DictWriter(h, fieldnames=fields)
            writer.writeheader()
            for r in records:
                d = r.get("design_si", [np.nan] * 5)
                row = {k: v for k, v in r.items() if k not in ("design_si",)}
                row.update({
                    "patch_length_mm": d[0] * 1e3,
                    "patch_width_mm": d[1] * 1e3,
                    "feed_x_fraction": d[2],
                    "feed_y_mm": d[3] * 1e3,
                    "terminal_span_y_mm": d[4] * 1e3,
                })
                writer.writerow(row)
    if ranked:
        short = []
        for robust_score, nominal_score, design, _result, _report in ranked:
            short.append({
                "robust_score": float(robust_score),
                "nominal_score": float(nominal_score),
                "design_si": np.asarray(design, float).tolist(),
            })
        (out / "robust_candidate_ranking.json").write_text(json.dumps(short, indent=2))
