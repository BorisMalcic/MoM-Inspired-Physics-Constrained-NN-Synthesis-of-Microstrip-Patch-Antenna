"""Comparison against common surrogate-modeling techniques.

All models in this module are trained only on full-wave MoM-generated targets.
They are intentionally lightweight NumPy/SciPy implementations so the project
remains reproducible...
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from time import perf_counter
import csv, json
import numpy as np

from nn import EnsembleSurrogate


class Standardizer:
    def fit(self, x):
        x = np.asarray(x, float)
        self.mean = np.mean(x, axis=0)
        self.std = np.std(x, axis=0)
        self.std = np.where(self.std < 1e-12, 1.0, self.std)
        return self
    def transform(self, x):
        return (np.asarray(x, float) - self.mean) / self.std
    def inverse(self, x):
        return np.asarray(x, float) * self.std + self.mean


def _poly_features(x: np.ndarray, degree: int) -> np.ndarray:
    x = np.asarray(x, float)
    feats = [np.ones((len(x), 1)), x]
    if degree >= 2:
        cols = []
        d = x.shape[1]
        for i in range(d):
            for j in range(i, d):
                cols.append((x[:, i] * x[:, j])[:, None])
        feats.append(np.hstack(cols))
    return np.hstack(feats)


class PolynomialRidge:
    def __init__(self, degree=1, alpha=1e-6):
        self.degree = int(degree)
        self.alpha = float(alpha)
    def fit(self, X, Y):
        self.xs = Standardizer().fit(X)
        self.ys = Standardizer().fit(Y)
        Phi = _poly_features(self.xs.transform(X), self.degree)
        YY = self.ys.transform(Y)
        A = Phi.T @ Phi + self.alpha * np.eye(Phi.shape[1])
        self.coef = np.linalg.solve(A, Phi.T @ YY)
        return self
    def predict(self, X):
        Phi = _poly_features(self.xs.transform(X), self.degree)
        return self.ys.inverse(Phi @ self.coef)


class KNNRegressor:
    def __init__(self, k=5, distance_power=2.0):
        self.k = int(k)
        self.distance_power = float(distance_power)
    def fit(self, X, Y):
        self.xs = Standardizer().fit(X)
        self.X = self.xs.transform(X)
        self.Y = np.asarray(Y, float)
        return self
    def predict(self, X):
        Xs = self.xs.transform(X)
        out = []
        for row in Xs:
            d = np.linalg.norm(self.X - row[None, :], axis=1)
            idx = np.argsort(d)[: max(1, min(self.k, len(self.X)))]
            w = 1.0 / np.maximum(d[idx], 1e-12) ** self.distance_power
            w /= np.sum(w)
            out.append(w @ self.Y[idx])
        return np.asarray(out, float)


class RBFKernelRidge:
    def __init__(self, alpha=1e-7, gamma=None):
        self.alpha = float(alpha)
        self.gamma = gamma
    def _kernel(self, A, B):
        aa = np.sum(A * A, axis=1)[:, None]
        bb = np.sum(B * B, axis=1)[None, :]
        d2 = np.maximum(aa + bb - 2.0 * A @ B.T, 0.0)
        return np.exp(-self.gamma * d2)
    def fit(self, X, Y):
        self.xs = Standardizer().fit(X)
        self.ys = Standardizer().fit(Y)
        self.X = self.xs.transform(X)
        YY = self.ys.transform(Y)
        if self.gamma is None:
            # Median heuristic on pairwise squared distances.
            if len(self.X) <= 1:
                self.gamma = 1.0
            else:
                aa = np.sum(self.X * self.X, axis=1)[:, None]
                d2 = np.maximum(aa + aa.T - 2.0 * self.X @ self.X.T, 0.0)
                vals = d2[np.triu_indices_from(d2, k=1)]
                med = float(np.median(vals[vals > 1e-15])) if np.any(vals > 1e-15) else 1.0
                self.gamma = 1.0 / max(med, 1e-12)
        K = self._kernel(self.X, self.X)
        self.alpha_coef = np.linalg.solve(K + self.alpha * np.eye(len(K)), YY)
        return self
    def predict(self, X):
        K = self._kernel(self.xs.transform(X), self.X)
        return self.ys.inverse(K @ self.alpha_coef)


def _metrics(y_true, y_pred):
    y_true = np.asarray(y_true, float)
    y_pred = np.asarray(y_pred, float)
    err = y_pred - y_true
    mse = float(np.mean(err ** 2))
    rmse = float(np.sqrt(mse))
    mae = float(np.mean(np.abs(err)))
    maxae = float(np.max(np.abs(err)))
    sse = float(np.sum(err ** 2))
    sst = float(np.sum((y_true - np.mean(y_true, axis=0, keepdims=True)) ** 2))
    r2 = float(1.0 - sse / max(sst, 1e-15))
    return {"rmse": rmse, "mae": mae, "max_abs_error": maxae, "r2": r2}


def _folds(n, k, rng):
    k = max(2, min(int(k), n))
    idx = rng.permutation(n)
    return np.array_split(idx, k)


def _build_model(name, cfg, train_size):
    if name == "linear_ridge":
        return PolynomialRidge(degree=1, alpha=1e-6)
    if name == "quadratic_ridge":
        return PolynomialRidge(degree=2, alpha=1e-5)
    if name == "rbf_kernel_ridge":
        return RBFKernelRidge(alpha=1e-7)
    if name == "knn_distance_weighted":
        return KNNRegressor(k=max(2, min(5, train_size)))
    if name == "forward_mlp_ensemble":
        return None
    raise ValueError(name)


def compare_surrogate_families(cfg, X, Y, outdir):
    """K-fold comparison of common surrogate families.

    Families compared: linear response surface, quadratic response surface,
    Gaussian RBF kernel ridge, weighted kNN, and the project's forward MLP
    ensemble.  All are trained on the same full-wave MoM dataset.
    """
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    X = np.asarray(X, float)
    Y = np.asarray(Y, float)
    methods = [
        "linear_ridge",
        "quadratic_ridge",
        "rbf_kernel_ridge",
        "knn_distance_weighted",
        "forward_mlp_ensemble",
    ]
    rng = np.random.default_rng(cfg.surrogate_comparison.seed)
    records = []
    if len(X) < 4 or not cfg.surrogate_comparison.enabled:
        summary = {"enabled": False, "reason": "disabled or too few samples"}
        (out / "surrogate_family_comparison_summary.json").write_text(json.dumps(summary, indent=2))
        return summary, records
    for rep in range(max(1, int(cfg.surrogate_comparison.repeats))):
        folds = _folds(len(X), cfg.surrogate_comparison.folds, rng)
        for fold_id, val_idx in enumerate(folds, 1):
            train_idx = np.setdiff1d(np.arange(len(X)), val_idx, assume_unique=False)
            for method in methods:
                t0 = perf_counter()
                if method == "forward_mlp_ensemble":
                    from dataclasses import replace
                    nn_cfg = replace(
                        cfg.nn,
                        epochs=max(20, int(round(cfg.nn.epochs * cfg.surrogate_comparison.epochs_factor))),
                        ensemble_size=max(1, min(cfg.nn.ensemble_size, cfg.surrogate_comparison.mlp_ensemble_size)),
                        seed=cfg.nn.seed + 7000 + 113 * rep + 17 * fold_id,
                    )
                    model = EnsembleSurrogate(nn_cfg).fit(
                        X[train_idx], Y[train_idx], validation_data=(X[val_idx], Y[val_idx])
                    )
                    pred, std = model.predict(X[val_idx])
                    uncertainty = float(np.mean(np.sqrt(np.mean(std ** 2, axis=1))))
                else:
                    model = _build_model(method, cfg, len(train_idx)).fit(X[train_idx], Y[train_idx])
                    pred = model.predict(X[val_idx])
                    uncertainty = float("nan")
                seconds = perf_counter() - t0
                m = _metrics(Y[val_idx], pred)
                m.update({
                    "method": method,
                    "repeat": rep + 1,
                    "fold": fold_id,
                    "train_samples": int(len(train_idx)),
                    "validation_samples": int(len(val_idx)),
                    "fit_predict_seconds": float(seconds),
                    "mean_uncertainty": uncertainty,
                })
                records.append(m)
    fields = [
        "method", "repeat", "fold", "train_samples", "validation_samples",
        "rmse", "mae", "max_abs_error", "r2", "fit_predict_seconds", "mean_uncertainty",
    ]
    with (out / "surrogate_family_comparison.csv").open("w", newline="") as h:
        w = csv.DictWriter(h, fieldnames=fields)
        w.writeheader()
        for r in records:
            w.writerow({k: r.get(k, "") for k in fields})
    summary = {"enabled": True, "methods": {}}
    for method in methods:
        rows = [r for r in records if r["method"] == method]
        summary["methods"][method] = {}
        for key in ["rmse", "mae", "max_abs_error", "r2", "fit_predict_seconds"]:
            vals = np.asarray([r[key] for r in rows if np.isfinite(r[key])], float)
            if vals.size:
                std = float(np.std(vals, ddof=1)) if vals.size > 1 else 0.0
                summary["methods"][method][key] = {
                    "mean": float(np.mean(vals)),
                    "std": std,
                    "ci95_half_width": float(1.96 * std / np.sqrt(vals.size)),
                    "min": float(np.min(vals)),
                    "max": float(np.max(vals)),
                }
    (out / "surrogate_family_comparison_summary.json").write_text(json.dumps(summary, indent=2))
    return summary, records
