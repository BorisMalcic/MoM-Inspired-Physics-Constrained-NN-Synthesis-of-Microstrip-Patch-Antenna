from __future__ import annotations
from dataclasses import replace
from pathlib import Path
import csv, json
import numpy as np

from nn import EnsembleSurrogate


def _metrics(y_true: np.ndarray, y_pred: np.ndarray, y_std: np.ndarray | None = None) -> dict:
    err = np.asarray(y_pred - y_true, float)
    mse = float(np.mean(err ** 2))
    rmse = float(np.sqrt(mse))
    mae = float(np.mean(np.abs(err)))
    maxae = float(np.max(np.abs(err)))
    sse = float(np.sum(err ** 2))
    sst = float(np.sum((y_true - np.mean(y_true, axis=0, keepdims=True)) ** 2))
    r2 = float(1.0 - sse / max(sst, 1e-15))
    out = {"rmse": rmse, "mae": mae, "max_abs_error": maxae, "r2": r2}
    if y_std is not None:
        uncertainty = np.sqrt(np.mean(np.asarray(y_std, float) ** 2, axis=1))
        sample_err = np.sqrt(np.mean(err ** 2, axis=1))
        if len(uncertainty) >= 2 and np.std(uncertainty) > 1e-15 and np.std(sample_err) > 1e-15:
            out["uncertainty_error_corr"] = float(np.corrcoef(uncertainty, sample_err)[0, 1])
        else:
            out["uncertainty_error_corr"] = float("nan")
        out["mean_ensemble_uncertainty"] = float(np.mean(uncertainty))
    return out


def _fold_indices(n: int, folds: int, rng: np.random.Generator):
    folds = max(2, min(int(folds), n))
    idx = rng.permutation(n)
    return np.array_split(idx, folds)


def cross_validate_surrogate(cfg, X, Y, outdir: str | Path):
    """K-fold cross-validation for the NN ensemble surrogate.

    This replaces a single split as the reported statistical validation.  The
    final model can still be trained on all data after cross-validation (CV) is complete.
    """
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    X = np.asarray(X, float)
    Y = np.asarray(Y, float)
    if not cfg.cross_validation.enabled or len(X) < 3:
        summary = {"enabled": False, "reason": "too few samples or disabled"}
        (out / "cross_validation_summary.json").write_text(json.dumps(summary, indent=2))
        return summary, []

    rng = np.random.default_rng(cfg.cross_validation.seed)
    records = []
    repeats = max(1, int(cfg.cross_validation.repeats))
    for rep in range(repeats):
        folds = _fold_indices(len(X), cfg.cross_validation.folds, rng)
        for fold_id, val_idx in enumerate(folds, 1):
            train_idx = np.setdiff1d(np.arange(len(X)), val_idx, assume_unique=False)
            nn_cfg = replace(
                cfg.nn,
                epochs=max(20, int(round(cfg.nn.epochs * cfg.cross_validation.epochs_factor))),
                seed=cfg.nn.seed + 1000 * rep + 17 * fold_id,
            )
            surrogate = EnsembleSurrogate(nn_cfg).fit(
                X[train_idx], Y[train_idx], validation_data=(X[val_idx], Y[val_idx])
            )
            pred, std = surrogate.predict(X[val_idx])
            m = _metrics(Y[val_idx], pred, std)
            m.update({
                "repeat": rep + 1,
                "fold": fold_id,
                "train_samples": int(len(train_idx)),
                "validation_samples": int(len(val_idx)),
            })
            records.append(m)

    numeric_keys = ["rmse", "mae", "max_abs_error", "r2", "mean_ensemble_uncertainty", "uncertainty_error_corr"]
    summary = {"enabled": True, "folds": int(cfg.cross_validation.folds), "repeats": repeats, "records": len(records)}
    for key in numeric_keys:
        vals = np.asarray([r[key] for r in records if key in r and np.isfinite(r[key])], float)
        if vals.size:
            summary[key] = {
                "mean": float(np.mean(vals)),
                "std": float(np.std(vals, ddof=1)) if vals.size > 1 else 0.0,
                "ci95_half_width": float(1.96 * (np.std(vals, ddof=1) if vals.size > 1 else 0.0) / np.sqrt(vals.size)),
                "min": float(np.min(vals)),
                "max": float(np.max(vals)),
            }

    with (out / "cross_validation_metrics.csv").open("w", newline="") as h:
        fields = ["repeat", "fold", "train_samples", "validation_samples"] + numeric_keys
        w = csv.DictWriter(h, fieldnames=fields)
        w.writeheader()
        for r in records:
            w.writerow({k: r.get(k, "") for k in fields})
    (out / "cross_validation_summary.json").write_text(json.dumps(summary, indent=2))
    return summary, records
