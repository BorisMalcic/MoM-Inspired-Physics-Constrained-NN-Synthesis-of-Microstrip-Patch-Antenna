# HFSS coordinate mapping
patchX_mm = 53.246000199   # width W
patchY_mm = 28.867894090  # resonant length L
feedX_mm = 0.145878123
feedY_mm = 8.891477998
boardX_mm = 62.000000000
boardY_mm = 60.000000000
substrate_h_mm = 1.530000000
eps_r = 4.4
loss_tan = 0.02
terminal_gap_mm = 0.500000000
terminal_span_y_mm = 3.542557068
port_model = 'sma_coax_50ohm'
coax_inner_radius_mm = 0.350000000
coax_shield_inner_radius_mm = 1.200000000
coax_dielectric_eps_r = 2.186176393940
coax_reference_impedance_ohm = 50.000000000
coax_eps_r_for_50ohm = 2.186176393943
