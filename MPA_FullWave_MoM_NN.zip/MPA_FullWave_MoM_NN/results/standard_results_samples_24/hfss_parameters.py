# HFSS coordinate mapping
patchX_mm = 55.200210945   # width W
patchY_mm = 28.773467520  # resonant length L
feedX_mm = 0.782332339
feedY_mm = 9.504099433
boardX_mm = 62.000000000
boardY_mm = 60.000000000
substrate_h_mm = 1.530000000
eps_r = 4.4
loss_tan = 0.02
terminal_gap_mm = 0.500000000
terminal_span_y_mm = 6.307000549
port_model = 'sma_coax_50ohm'
coax_inner_radius_mm = 0.350000000
coax_shield_inner_radius_mm = 1.200000000
coax_dielectric_eps_r = 2.186176393940
coax_reference_impedance_ohm = 50.000000000
coax_eps_r_for_50ohm = 2.186176393943
