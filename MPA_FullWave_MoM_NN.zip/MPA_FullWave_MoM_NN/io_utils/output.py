from __future__ import annotations
from pathlib import Path
import csv, json
import numpy as np
import matplotlib.pyplot as plt
from metrics import response_arrays, band_metrics
from mom.farfield import normalized_cuts
from mom.port import port_reference_impedance, coax_characteristic_impedance, coax_eps_r_for_impedance


def save_response(results, path):
    f, z, s11, vswr = response_arrays(results)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as h:
        w = csv.writer(h)
        w.writerow(["frequency_hz", "re_z_ohm", "im_z_ohm", "s11_db", "vswr", "condition_number"])
        for r in results:
            w.writerow([r.frequency_hz, r.zin_ohm.real, r.zin_ohm.imag, r.s11_db, r.vswr, r.condition_number])


def _plot_xy(x, ys, labels, ylabel, path):
    plt.figure(figsize=(7, 4.5))
    for y, label in zip(ys, labels):
        plt.plot(x, y, label=label)
    plt.xlabel("Frequency (GHz)")
    plt.ylabel(ylabel)
    plt.grid(True, alpha=0.3)
    if len(labels) > 1:
        plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=160)
    plt.close()


def save_all(cfg, geometry, results, modes, center_coefficients, outdir, history=None, design_vector=None, validated=None):
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    save_response(results, out / "frequency_response.csv")

    f, z, s11, vswr = response_arrays(results)
    ghz = f / 1e9
    zref = port_reference_impedance(cfg.port)

    _plot_xy(ghz, [s11], ["S11"], "S11 (dB)", out / "s11.png")
    _plot_xy(ghz, [z.real, z.imag], ["Re(Zin)", "Im(Zin)"], "Impedance (ohm)", out / "zin.png")
    _plot_xy(ghz, [vswr], ["VSWR"], "VSWR", out / "vswr.png")

    gamma = (z - zref) / (z + zref)
    plt.figure(figsize=(5, 5))
    plt.plot(gamma.real, gamma.imag, "o-")
    plt.axhline(0, color="k", lw=0.6)
    plt.axvline(0, color="k", lw=0.6)
    plt.gca().set_aspect("equal")
    plt.grid(True, alpha=0.3)
    plt.xlabel("Re(Gamma)")
    plt.ylabel("Im(Gamma)")
    plt.tight_layout()
    plt.savefig(out / "smith_chart.png", dpi=160)
    plt.close()

    metrics = band_metrics(results)
    metrics["geometry"] = {
        "patch_length_mm": geometry.patch_length_m * 1e3,
        "patch_width_mm": geometry.patch_width_m * 1e3,
        "feed_x_mm": geometry.feed_x_m * 1e3,
        "feed_y_mm": geometry.feed_y_m * 1e3,
        "terminal_gap_mm": geometry.terminal_gap_m * 1e3,
        "terminal_span_y_mm": geometry.terminal_span_y_m * 1e3,
        "board_x_mm": geometry.board_x_m * 1e3,
        "board_y_mm": geometry.board_y_m * 1e3,
    }
    metrics["port"] = {
        "port_model": cfg.port.port_model,
        "reference_impedance_ohm": zref,
        "inner_conductor_radius_mm": cfg.port.inner_conductor_radius_m * 1e3,
        "shield_inner_radius_mm": cfg.port.shield_inner_radius_m * 1e3,
        "coax_dielectric_eps_r": cfg.port.coax_dielectric_eps_r,
        "coax_z0_from_dimensions_ohm": coax_characteristic_impedance(
            cfg.port.inner_conductor_radius_m,
            cfg.port.shield_inner_radius_m,
            cfg.port.coax_dielectric_eps_r,
        ),
        "coax_eps_r_for_50ohm": coax_eps_r_for_impedance(
            cfg.port.inner_conductor_radius_m,
            cfg.port.shield_inner_radius_m,
            50.0,
        ),
    }
    (out / "summary.json").write_text(json.dumps(metrics, indent=2))

    if design_vector is not None:
        (out / "best_design.json").write_text(
            json.dumps({"design_vector_si": np.asarray(design_vector).tolist(), "metrics": metrics}, indent=2)
        )

    hfss = f'''# HFSS coordinate mapping
patchX_mm = {geometry.patch_width_m*1e3:.9f}   # width W
patchY_mm = {geometry.patch_length_m*1e3:.9f}  # resonant length L
feedX_mm = {geometry.feed_y_m*1e3:.9f}
feedY_mm = {geometry.feed_x_m*1e3:.9f}
boardX_mm = {geometry.board_y_m*1e3:.9f}
boardY_mm = {geometry.board_x_m*1e3:.9f}
substrate_h_mm = {cfg.material.substrate_h_m*1e3:.9f}
eps_r = {cfg.material.eps_r}
loss_tan = {cfg.material.loss_tan}
terminal_gap_mm = {geometry.terminal_gap_m*1e3:.9f}
terminal_span_y_mm = {geometry.terminal_span_y_m*1e3:.9f}
port_model = '{cfg.port.port_model}'
coax_inner_radius_mm = {cfg.port.inner_conductor_radius_m*1e3:.9f}
coax_shield_inner_radius_mm = {cfg.port.shield_inner_radius_m*1e3:.9f}
coax_dielectric_eps_r = {cfg.port.coax_dielectric_eps_r:.12f}
coax_reference_impedance_ohm = {zref:.9f}
coax_eps_r_for_50ohm = {coax_eps_r_for_impedance(cfg.port.inner_conductor_radius_m,cfg.port.shield_inner_radius_m,50.0):.12f}
'''
    (out / "hfss_parameters.py").write_text(hfss)

    if center_coefficients is not None:
        theta, e, h = normalized_cuts(geometry, modes, center_coefficients, 2.44175e9)
        plt.figure(figsize=(7, 4.5))
        plt.plot(theta, e, label="E-plane")
        plt.plot(theta, h, label="H-plane")
        plt.ylim(-40, 1)
        plt.grid(True, alpha=0.3)
        plt.xlabel("Theta (deg)")
        plt.ylabel("Normalized pattern (dB)")
        plt.legend()
        plt.tight_layout()
        plt.savefig(out / "radiation_pattern.png", dpi=160)
        plt.close()

    if history:
        plt.figure(figsize=(7, 4.5))
        for i, hist in enumerate(history):
            plt.plot(hist[:, 0], hist[:, 2], label=f"ensemble {i + 1}")
        plt.yscale("log")
        plt.xlabel("Epoch")
        plt.ylabel("Validation MSE")
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        plt.savefig(out / "nn_training_history.png", dpi=160)
        plt.close()

    if validated is not None:
        records = []
        for score, x, _ in validated:
            records.append({"score": float(score), "design_si": np.asarray(x).tolist()})
        (out / "validated_candidates.json").write_text(json.dumps(records, indent=2))
