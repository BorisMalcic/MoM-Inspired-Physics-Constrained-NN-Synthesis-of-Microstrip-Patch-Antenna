from config import profile_config
from mom.solver import SpectralMoMSolver

cfg=profile_config('quick')
solver=SpectralMoMSolver(cfg)
for r in solver.sweep(cfg.geometry):
    print(r.frequency_hz/1e9,r.zin_ohm,r.s11_db,r.vswr)
