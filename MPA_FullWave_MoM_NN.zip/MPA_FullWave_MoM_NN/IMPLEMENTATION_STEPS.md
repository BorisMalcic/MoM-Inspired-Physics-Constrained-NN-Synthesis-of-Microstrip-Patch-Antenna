# Implementation steps

## 1\. Spectral-domain MoM backend

Code `mom/solver.py` builds the MoM matrix from the grounded-slab TE/TM spectral dyadic operator. The unknown is the patch surface current expanded in entire-domain vector basis functions from `mom/basis.py`.

For each frequency:
basis Fourier transforms -> grounded-slab dyadic -> Galerkin matrix -> solve ZI=V -> Zin=V/I


## 2\. SMA/coax reference

`mom/port.py` computes the SMA/coax characteristic impedance from the specified radii and dielectric constant. S-parameters are referenced to this impedance.

## 3\. Dataset

`dataset.py` generates Latin-Hypercube geometries, runs the MoM solver, and stores normalized complex impedance spectra as targets.

## 4\. Neural ensemble

`nn/ensemble.py` trains several independent NumPy MLPs. The ensemble mean is used as the prediction; the standard deviation is used as uncertainty.

## 5\. Active learning

`active\_learning.py` selects additional MoM simulations based on predicted matching quality, ensemble uncertainty, and distance from the existing dataset.

## 6\. Inverse synthesis

`optimization/synthesize.py` searches a large candidate pool with the surrogate, validates selected candidates with full-wave MoM, and performs direct local MoM refinement.

## 7\. Robustness

`robustness.py` Monte-Carlo perturbs the final candidate and re-ranks top nominal candidates by a robust full-wave MoM score.

## 8\. Output

`io\_utils/output.py` exports CSV, JSON, plots, and `hfss\_parameters.py` for HFSS verification.

