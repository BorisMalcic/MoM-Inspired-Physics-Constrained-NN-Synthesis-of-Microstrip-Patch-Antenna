from __future__ import annotations
from dataclasses import dataclass, field, asdict
from time import perf_counter
from pathlib import Path
import csv, json


@dataclass
class RuntimeEvent:
    name: str
    seconds: float
    metadata: dict = field(default_factory=dict)


class CostTracker:
    """Small global runtime/cost tracker used for reporting experiments.

    It does not change numerical results.  It only records elapsed wall-clock
    time and basic MoM cost counters so a paper can report runtime.
    """

    def __init__(self):
        self.reset()

    def reset(self):
        self.events: list[RuntimeEvent] = []
        self.mom_sweeps = 0
        self.mom_point_solves = 0
        self.mom_solve_seconds = 0.0
        self.mom_frequencies = 0

    def add_event(self, name: str, seconds: float, **metadata):
        self.events.append(RuntimeEvent(name, float(seconds), dict(metadata)))

    def add_mom_sweep(self, seconds: float, n_frequencies: int, n_modes: int):
        self.mom_sweeps += 1
        self.mom_point_solves += int(n_frequencies)
        self.mom_frequencies += int(n_frequencies)
        self.mom_solve_seconds += float(seconds)
        self.add_event(
            "mom_sweep",
            seconds,
            n_frequencies=int(n_frequencies),
            n_modes=int(n_modes),
        )

    def summary(self):
        by_name = {}
        for e in self.events:
            d = by_name.setdefault(e.name, {"count": 0, "seconds": 0.0})
            d["count"] += 1
            d["seconds"] += e.seconds
        return {
            "mom_sweeps": self.mom_sweeps,
            "mom_point_solves": self.mom_point_solves,
            "mom_frequencies": self.mom_frequencies,
            "mom_solve_seconds": self.mom_solve_seconds,
            "events_by_name": by_name,
        }

    def save(self, outdir: str | Path):
        out = Path(outdir)
        out.mkdir(parents=True, exist_ok=True)
        (out / "runtime_summary.json").write_text(json.dumps(self.summary(), indent=2))
        with (out / "runtime_events.csv").open("w", newline="") as h:
            fields = ["name", "seconds", "metadata_json"]
            writer = csv.DictWriter(h, fieldnames=fields)
            writer.writeheader()
            for e in self.events:
                writer.writerow({
                    "name": e.name,
                    "seconds": e.seconds,
                    "metadata_json": json.dumps(e.metadata, sort_keys=True),
                })


TRACKER = CostTracker()


class timer:
    def __init__(self, name: str, **metadata):
        self.name = name
        self.metadata = metadata
    def __enter__(self):
        self.t0 = perf_counter()
        return self
    def __exit__(self, exc_type, exc, tb):
        self.seconds = perf_counter() - self.t0
        TRACKER.add_event(self.name, self.seconds, **self.metadata)
        return False
