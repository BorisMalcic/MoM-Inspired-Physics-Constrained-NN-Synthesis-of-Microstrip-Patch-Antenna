"""Separate inverse MLP and comparison against direct refinement baselines.

The forward surrogate is trained as geometry -> MoM response.  The inverse MLP
is trained separately as desired response -> candidate geometry.  Because the
inverse antenna-design mapping is generally many-to-one, inverse predictions are
reported as seeds and are always re-evaluated/refined by the full-wave MoM.
"""
from __future__ import annotations
from dataclasses import replace
from pathlib import Path
from time import perf_counter
import csv, json
import numpy as np
from scipy.optimize import minimize

from nn.mlp_numpy import MLP, Standardizer
from dataset import clip_design, design_bounds, geometry_from_design
from metrics import impedance_from_target, objective_from_impedance, objective_from_results, band_metrics
from mom.port import port_reference_impedance


class InverseMLPEnsemble:
    def __init__(self, cfg):
        self.cfg = cfg
        self.models = []
    def fit(self, X_design, Y_response):
        X_design = np.asarray(X_design, float)
        Y_response = np.asarray(Y_response, float)
        self.ys = Standardizer().fit(Y_response)
        self.xs = Standardizer().fit(X_design)
        Yin = self.ys.transform(Y_response)
        Xout = self.xs.transform(X_design)
        self.models = []
        histories = []
        n_models = max(1, int(self.cfg.inverse_model.ensemble_size))
        for i in range(n_models):
            model = MLP(
                Yin.shape[1],
                Xout.shape[1],
                hidden=self.cfg.inverse_model.hidden,
                depth=self.cfg.inverse_model.depth,
                seed=self.cfg.inverse_model.seed + 101 * i,
            )
            hist = model.fit(
                Yin,
                Xout,
                epochs=self.cfg.inverse_model.epochs,
                batch_size=self.cfg.inverse_model.batch_size,
                lr=self.cfg.inverse_model.learning_rate,
                patience=self.cfg.inverse_model.patience,
                seed=self.cfg.inverse_model.seed + 37 * i,
            )
            self.models.append(model)
            histories.append(hist)
        self.histories = histories
        return self
    def predict_members(self, target_response):
        y = self.ys.transform(np.asarray(target_response, float).reshape(1, -1))
        return np.vstack([self.xs.inverse(m.predict(y))[0] for m in self.models])
    def predict(self, target_response):
        members = self.predict_members(target_response)
        return np.mean(members, axis=0), np.std(members, axis=0), members


def desired_response_target(cfg):
    n = len(cfg.sweep.synthesis_frequencies_hz)
    return np.r_[np.ones(n), np.zeros(n)]


def _score_target(y, cfg):
    return objective_from_impedance(impedance_from_target(y, port_reference_impedance(cfg.port)), port_reference_impedance(cfg.port))


def _evaluate_design(design, cfg, solver):
    t0 = perf_counter()
    design = clip_design(design, cfg)
    result = solver.sweep(geometry_from_design(design, cfg))
    seconds = perf_counter() - t0
    score = objective_from_results(result)
    return {"design": design, "result": result, "score": float(score), "seconds": float(seconds)}


def _public_record(method, rec, extra=None):
    m = band_metrics(rec["result"])
    d = np.asarray(rec["design"], float)
    row = {
        "method": method,
        "score": float(rec["score"]),
        "seconds": float(rec.get("seconds", 0.0)),
        "evaluations": int(rec.get("evaluations", 1)),
        "patch_length_mm": float(d[0] * 1e3),
        "patch_width_mm": float(d[1] * 1e3),
        "feed_x_fraction": float(d[2]),
        "feed_y_mm": float(d[3] * 1e3),
        "terminal_span_y_mm": float(d[4] * 1e3),
        "worst_s11_db": float(m["worst_s11_db"]),
        "center_re_z_ohm": float(m["center_re_z_ohm"]),
        "center_im_z_ohm": float(m["center_im_z_ohm"]),
        "center_s11_db": float(m["center_s11_db"]),
        "band_target_pass": bool(m["band_target_pass"]),
    }
    if extra:
        row.update(extra)
    return row


def _best_dataset_seed(X, Y, cfg):
    scores = np.asarray([_score_target(y, cfg) for y in Y], float)
    return clip_design(X[int(np.argmin(scores))], cfg)


def _stochastic_refine(seed, cfg, solver, evaluations, rng):
    bounds = design_bounds(cfg)
    span = bounds[:, 1] - bounds[:, 0]
    step = cfg.inverse_comparison.stochastic_sigma_fraction * span
    best = _evaluate_design(seed, cfg, solver)
    total_seconds = best["seconds"]
    n = max(1, int(evaluations))
    for _ in range(max(0, n - 1)):
        trial = clip_design(best["design"] + rng.normal(0.0, step, size=len(seed)), cfg)
        rec = _evaluate_design(trial, cfg, solver)
        total_seconds += rec["seconds"]
        if rec["score"] < best["score"]:
            best = rec
    best["seconds"] = total_seconds
    best["evaluations"] = n
    return best


def _nelder_mead_refine(seed, cfg, solver, evaluations):
    evals = 0
    seconds = 0.0
    best = {"score": float("inf"), "design": clip_design(seed, cfg), "result": None, "seconds": 0.0}
    def objective(q):
        nonlocal evals, seconds, best
        evals += 1
        rec = _evaluate_design(q, cfg, solver)
        seconds += rec["seconds"]
        if rec["score"] < best["score"]:
            best = rec
        return rec["score"]
    res = minimize(
        objective,
        clip_design(seed, cfg),
        method="Nelder-Mead",
        options={"maxfev": max(1, int(evaluations)), "maxiter": max(1, int(evaluations)), "xatol": 1e-5, "fatol": 1e-4, "disp": False},
    )
    candidate = _evaluate_design(res.x, cfg, solver)
    seconds += candidate["seconds"]
    evals += 1
    if candidate["score"] < best["score"]:
        best = candidate
    best["seconds"] = seconds
    best["evaluations"] = evals
    return best


def compare_inverse_design_methods(cfg, solver, X, Y, outdir):
    """Compare inverse MLP with refinement-only and direct optimization baselines."""
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    if not cfg.inverse_comparison.enabled or len(X) < 3:
        summary = {"enabled": False, "reason": "disabled or too few samples"}
        (out / "inverse_design_comparison_summary.json").write_text(json.dumps(summary, indent=2))
        return summary, []

    t_train = perf_counter()
    inv = InverseMLPEnsemble(cfg).fit(X, Y)
    train_seconds = perf_counter() - t_train
    target = desired_response_target(cfg)
    mean_design, std_design, members = inv.predict(target)
    rng = np.random.default_rng(cfg.inverse_comparison.seed)
    records = []

    # 1) Inverse MLP only: evaluate mean and member predictions, keep best.
    inverse_candidates = [mean_design] + [m for m in members]
    inverse_records = []
    for d in inverse_candidates[: max(1, cfg.inverse_comparison.inverse_candidates)]:
        inverse_records.append(_evaluate_design(d, cfg, solver))
    inv_best = min(inverse_records, key=lambda r: r["score"])
    inv_best["seconds"] += train_seconds
    inv_best["evaluations"] = len(inverse_records)
    records.append(_public_record("inverse_mlp_only", inv_best, {"training_seconds": float(train_seconds)}))

    # 2) Inverse MLP seed + stochastic full-wave refinement.
    rec = _stochastic_refine(inv_best["design"], cfg, solver, cfg.inverse_comparison.refine_evaluations, rng)
    rec["seconds"] += train_seconds
    records.append(_public_record("inverse_mlp_plus_stochastic_refinement", rec, {"training_seconds": float(train_seconds)}))

    # 3) Best existing dataset sample + same stochastic refinement budget.
    data_seed = _best_dataset_seed(X, Y, cfg)
    rec = _stochastic_refine(data_seed, cfg, solver, cfg.inverse_comparison.refine_evaluations, rng)
    records.append(_public_record("stochastic_refinement_from_dataset_best", rec, {"training_seconds": 0.0}))

    # 4) Direct optimization from best dataset seed using the same full-wave backend.
    rec = _nelder_mead_refine(data_seed, cfg, solver, cfg.inverse_comparison.direct_optimization_evaluations)
    records.append(_public_record("direct_nelder_mead_from_dataset_best", rec, {"training_seconds": 0.0}))

    fields = list(records[0].keys())
    with (out / "inverse_design_comparison.csv").open("w", newline="") as h:
        w = csv.DictWriter(h, fieldnames=fields)
        w.writeheader()
        for r in records:
            w.writerow(r)

    methods = sorted(set(r["method"] for r in records))
    summary = {
        "enabled": True,
        "justification": {
            "forward_mlp_role": "geometry -> MoM response, used for fast response prediction, uncertainty, and surrogate search",
            "inverse_mlp_role": "desired response -> seed geometry, used as a non-iterative candidate generator, then full-wave validated",
            "why_separate": "the inverse map is many-to-one and ill-posed; a separate inverse MLP provides fast seeds, while the forward MLP remains the calibrated response model used for ranking and uncertainty",
            "why_baselines": "inverse seeds are compared with stochastic refinement alone and direct full-wave Nelder-Mead refinement to show whether inverse learning adds value beyond optimization",
        },
        "methods": {m: [r for r in records if r["method"] == m][0] for m in methods},
        "best_method_by_score": min(records, key=lambda r: r["score"])["method"],
    }
    (out / "inverse_design_comparison_summary.json").write_text(json.dumps(summary, indent=2))
    return summary, records
