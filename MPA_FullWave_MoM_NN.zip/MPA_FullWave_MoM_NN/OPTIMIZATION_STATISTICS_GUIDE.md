# Optimization, Cross-Validation and Statistical Report



## Added modules

* `optimization/genetic\_algorithm.py` — direct full-wave MoM genetic algorithm
and direct random-search baseline.
* `cross\_validation.py` — repeated k-fold cross-validation of the NN ensemble.
* `benchmarks.py` — runtime and performance comparison of the active NN method,
random search, and GA.
* `experiment\_tracking.py` — wall-clock timing and MoM cost tracking.
* `statistical\_evaluation.py` — consolidated statistical report.
* 



## Genetic Algorithm (GA) 

The GA is a direct optimizer: every fitness evaluation is a full-wave MoM sweep.
It uses elitism, arithmetic crossover, Gaussian mutation, clipping to physical
bounds, and full-wave objective re-evaluation.

The GA is not used to replace the proposed NN method. It is included as a
baseline for comparison in a paper.

## 

## Cross-validation

The surrogate is evaluated by repeated k-fold cross-validation instead of a
single random train/validation/test split. The report includes:

* RMSE of normalized complex impedance target;
* MAE;
* maximum absolute error;
* coefficient of determination R2;
* ensemble uncertainty vs error correlation;
* 95 percent confidence intervals across folds/repeats.

Outputs:

* `results/cross\_validation\_metrics.csv`
* `results/cross\_validation\_summary.json`

## 

## Runtime and computational cost

The workflow records:

* number of MoM sweeps;
* number of frequency point solves;
* cumulative MoM solve time;
* timing of dataset generation, active learning, cross-validation, inverse
search, robust re-ranking, GA/random baselines and final display sweep.

Outputs:

* `results/runtime\_events.csv`
* `results/runtime\_summary.json`

## 

## Method comparison

Run:

python main.py --mode synthesize --profile quick --run-benchmarks



or, for a stronger experiment:

python main.py --mode synthesize --profile standard --run-benchmarks



The benchmark suite compares:

1. proposed active-learning NN surrogate method;
2. direct full-wave random search;
3. direct full-wave genetic algorithm.

Outputs:

* `results/method\_comparison.csv`
* `results/method\_comparison\_summary.json`

## 

## Statistical evaluation

The final consolidated report is:

* `results/statistical\_evaluation.json`

It combines cross-validation, robust tolerance, method comparison and runtime
summaries in one JSON file suitable for a Table presentaton in a paper.

## 

## Description

> A full-wave spectral MoM dataset is used to train an ensemble neural surrogate.
> The surrogate is assessed with repeated k-fold cross-validation and augmented
> by uncertainty-aware active learning. Final candidates are re-evaluated by MoM
> and compared against direct random search and GA baselines in terms of objective
> value, runtime, number of full-wave solves and robustness under fabrication
> tolerances.



> The project now includes two additional comparison layers.

### A. Existing surrogate families

`surrogate\_baselines.py` evaluates common surrogate modeling alternatives on the
same full-wave MoM dataset:

* linear ridge response surface;
* quadratic ridge response surface;
* Gaussian RBF/kernel ridge surrogate;
* weighted k-nearest-neighbour local surrogate;
* proposed forward MLP ensemble.

Run with:

python main.py --mode synthesize --profile quick --force-dataset --run-benchmarks



Outputs:

results/surrogate\_family\_comparison.csv
results/surrogate\_family\_comparison\_summary.json



These files support a table comparing RMSE, MAE, max error, R2 and runtime.

### B. Separate inverse MLP justification

The inverse MLP is not used as a replacement for the forward surrogate.  It is a
candidate generator for the bad-posed inverse map:

desired impedance spectrum -> geometry seed



Every inverse-MLP design is re-evaluated by full-wave MoM.  The comparison module
benchmarks it against:

* inverse MLP only;
* inverse MLP plus stochastic full-wave refinement;
* stochastic refinement started from the best existing dataset sample;
* direct Nelder-Mead full-wave refinement started from the best existing dataset sample.

Outputs are in folders:

results/inverse\_design\_comparison.csv
results/inverse\_design\_comparison\_summary.json



This directly addresses whether inverse learning improves over direct refinement
alone.

