from __future__ import annotations
from dataclasses import replace
import csv
from pathlib import Path
import numpy as np
from mom.solver import SpectralMoMSolver


def run_convergence(cfg,outfile='results/convergence.csv'):
    levels=[
        ('coarse',(2,1,1,1),12,24,25.0),
        ('medium',(3,2,2,3),24,48,45.0),
        ('fine',(4,3,3,4),40,80,65.0),
    ]
    rows=[]
    for name,modes,radial,angular,kmax in levels:
        c=replace(cfg)
        c.basis=replace(cfg.basis,mx_x=modes[0],ny_x=modes[1],mx_y=modes[2],ny_y=modes[3])
        c.spectral=replace(cfg.spectral,radial_order_per_segment=radial,angular_samples=angular,k_rho_max_factor=kmax)
        c.sweep=replace(cfg.sweep,synthesis_frequencies_hz=np.array([2.44175e9]))
        solver=SpectralMoMSolver(c);r=solver.sweep(c.geometry)[0]
        rows.append([name,len(solver.modes),radial,angular,kmax,r.zin_ohm.real,r.zin_ohm.imag,r.s11_db,r.condition_number])
        print(name,r.zin_ohm,r.s11_db)
    path=Path(outfile);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',newline='') as h:
        w=csv.writer(h);w.writerow(['level','modes','radial_order','angular_samples','kmax_factor','re_z','im_z','s11_db','condition']);w.writerows(rows)
    return rows
