from __future__ import annotations
from dataclasses import replace
from pathlib import Path
import csv
import numpy as np

from dataset import latin_hypercube, design_bounds, geometry_from_design, clip_design
from metrics import impedance_from_target, objective_from_impedance, spectral_target
from mom.port import port_reference_impedance
from nn import EnsembleSurrogate


def _normalized_distance(candidate: np.ndarray, X: np.ndarray, bounds: np.ndarray) -> float:
    if X.size == 0:
        return float("inf")
    scale = bounds[:, 1] - bounds[:, 0] + 1e-15
    d = np.linalg.norm((X - candidate[None, :]) / scale[None, :], axis=1)
    return float(np.min(d))


def _uncertainty_score(std_target: np.ndarray) -> float:
    # Scale-independent uncertainty in normalized impedance target units.
    return float(np.sqrt(np.mean(np.asarray(std_target, float) ** 2)))


def select_active_candidates(cfg, surrogate, X_existing, n_select: int, seed_offset: int = 0):
    """Select new MoM simulations using exploitation + uncertainty + diversity.

    This is not a geometric/cavity model.  It uses only the NN ensemble's
    prediction of the MoM-generated impedance target and an explicit distance
    term in design space to avoid repeated samples.
    """
    zref = port_reference_impedance(cfg.port)
    pool = latin_hypercube(cfg.active.candidate_pool, cfg, cfg.nn.seed + 5000 + seed_offset)
    mean, std = surrogate.predict(pool)
    bounds = design_bounds(cfg)

    acquisition = []
    for row, mu, sig in zip(pool, mean, std):
        z = impedance_from_target(mu, zref)
        pred_obj = objective_from_impedance(z, zref)
        uncert = _uncertainty_score(sig)
        dist = _normalized_distance(row, X_existing, bounds)
        # Lower is better.  Negative uncertainty/diversity terms force the loop
        # to explore uncertain but plausible regions.
        acq = pred_obj - cfg.active.uncertainty_weight * uncert - cfg.active.diversity_weight * dist
        acquisition.append((acq, pred_obj, uncert, dist, row))
    acquisition.sort(key=lambda t: t[0])

    def far_enough_from_chosen(row: np.ndarray) -> bool:
        scale = bounds[:, 1] - bounds[:, 0] + 1e-15
        for _acq, _pred, _uncert, _dist, prev_row in chosen:
            if np.linalg.norm((row - prev_row) / scale) < cfg.active.min_normalized_distance:
                return False
        return True

    chosen = []

    # First pass: enforce distance from both the existing dataset and already
    # selected active-learning points.
    for acq, pred, uncert, dist, row in acquisition:
        if dist < cfg.active.min_normalized_distance:
            continue
        if not far_enough_from_chosen(row):
            continue
        chosen.append((acq, pred, uncert, dist, row))
        if len(chosen) >= n_select:
            break

    # Fallback: if the distance constraint is too strict, still return enough
    # candidates, but keep them unique and ordered by acquisition score.
    if len(chosen) < n_select:
        for item in acquisition:
            row = item[4]
            if any(np.allclose(row, chosen_item[4]) for chosen_item in chosen):
                continue
            chosen.append(item)
            if len(chosen) >= n_select:
                break

    return chosen[:n_select]


def active_learning_loop(cfg, solver, X, Y, outdir: str | Path):
    """Run active learning and return (X_augmented, Y_augmented, surrogate, records).

    Each active sample is evaluated by the same full-wave spectral MoM solver
    used for the initial dataset.  The NN is retrained after every iteration.
    """
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    X = np.asarray(X, float)
    Y = np.asarray(Y, float)
    records = []

    surrogate = EnsembleSurrogate(cfg.nn).fit(X, Y)
    if not cfg.active.enabled or cfg.active.iterations <= 0:
        return X, Y, surrogate, records

    for iteration in range(1, cfg.active.iterations + 1):
        chosen = select_active_candidates(
            cfg, surrogate, X, cfg.active.acquisitions_per_iteration, seed_offset=iteration
        )
        new_X = []
        new_Y = []
        for rank, (acq, pred_score, uncert, dist, design) in enumerate(chosen, 1):
            geometry = geometry_from_design(design, cfg)
            result = solver.sweep(geometry)
            target = spectral_target(result, port_reference_impedance(cfg.port))
            actual = objective_from_impedance(impedance_from_target(target, port_reference_impedance(cfg.port)), port_reference_impedance(cfg.port))
            err = float(np.sqrt(np.mean((target - surrogate.predict(design[None, :])[0][0]) ** 2)))
            new_X.append(design)
            new_Y.append(target)
            records.append({
                "iteration": iteration,
                "rank": rank,
                "acquisition": float(acq),
                "predicted_objective": float(pred_score),
                "ensemble_uncertainty": float(uncert),
                "nearest_dataset_distance": float(dist),
                "actual_objective": float(actual),
                "target_rmse_vs_surrogate": err,
                "patch_length_mm": float(design[0] * 1e3),
                "patch_width_mm": float(design[1] * 1e3),
                "feed_x_fraction": float(design[2]),
                "feed_y_mm": float(design[3] * 1e3),
                "terminal_span_y_mm": float(design[4] * 1e3),
            })
            print(
                f"active {iteration}.{rank}: pred={pred_score:.5f} uncert={uncert:.5f} "
                f"actual={actual:.5f} L={design[0]*1e3:.3f} W={design[1]*1e3:.3f}"
            )
        if new_X:
            X = np.vstack([X, np.asarray(new_X, float)])
            Y = np.vstack([Y, np.asarray(new_Y, float)])

        # Refit.  To reduce runtime, active retraining can use fewer epochs.
        old_epochs = cfg.nn.epochs
        cfg.nn.epochs = max(20, int(round(old_epochs * cfg.active.retrain_epochs_factor)))
        surrogate = EnsembleSurrogate(cfg.nn).fit(X, Y)
        cfg.nn.epochs = old_epochs

        np.savez_compressed(outdir / "active_augmented_dataset.npz", X=X, Y=Y)

    save_active_records(records, outdir / "active_learning_history.csv")
    return X, Y, surrogate, records


def save_active_records(records, path: str | Path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if not records:
        path.write_text("iteration,rank\n")
        return
    fields = list(records[0].keys())
    with path.open("w", newline="") as h:
        writer = csv.DictWriter(h, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)
