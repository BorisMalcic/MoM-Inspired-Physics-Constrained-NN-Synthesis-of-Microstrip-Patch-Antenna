# Surrogate and inverse-design comparison 

# 

# 1\. Comparison against existing surrogate families

The script now reports k-fold performance for several surrogate families trained
on the same full-wave MoM dataset:

* `linear\_ridge`: first-order response-surface model;
* `quadratic\_ridge`: second-order response-surface model;
* `rbf\_kernel\_ridge`: Gaussian radial-basis/kernel surrogate;
* `knn\_distance\_weighted`: local interpolation baseline;
* `forward\_mlp\_ensemble`: the proposed neural ensemble surrogate.



Outputs:

results/surrogate\_family\_comparison.csv
results/surrogate\_family\_comparison\_summary.json

The comparison reports RMSE, MAE, maximum absolute error, R2 and runtime.  This
helps justify why the forward MLP ensemble is used instead of only a classical
response surface, RBF, or nearest-neighbour surrogate.

## 2\. Separate forward and inverse MLPs

The forward MLP learns the well-posed map:

antenna geometry -> MoM-computed impedance spectrum



It is used for response prediction, uncertainty estimation, active learning and
fast inverse search.



The inverse MLP learns the bad-posed map:

desired impedance spectrum -> candidate geometry

Note:

**Because many different geometries can produce similar impedance spectra, the
inverse MLP is not used as final proof.  It is only a fast seed generator. Every
inverse design is re-evaluated by the full-wave MoM solver and can be refined
stochastically.**

## 3\. Inverse MLP comparison

The project compares:

* `inverse\_mlp\_only`;
* `inverse\_mlp\_plus\_stochastic\_refinement`;
* `stochastic\_refinement\_from\_dataset\_best`;
* `direct\_nelder\_mead\_from\_dataset\_best`.

Outputs:

results/inverse\_design\_comparison.csv
results/inverse\_design\_comparison\_summary.json

This directly tests whether the inverse MLP adds useful information beyond
stochastic refinement or direct optimization alone.

## 4\. Commands to run 

python main.py --mode synthesize --profile quick --force-dataset --run-benchmarks

python main.py --mode synthesize --profile standard --run-benchmarks

If runtime is too high:

python main.py --mode synthesize --profile standard --run-benchmarks --disable-inverse-comparison

or:

python main.py --mode synthesize --profile standard --run-benchmarks --disable-surrogate-comparison

