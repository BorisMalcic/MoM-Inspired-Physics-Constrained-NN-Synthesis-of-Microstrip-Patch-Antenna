# Surrogate and inverse-design comparison guide

This upgrade addresses common requests for stronger benchmarking of an
MoM-neural synthesis workflow.

## 1. Comparison against existing surrogate families

The script now reports k-fold performance for several surrogate families trained
on the same full-wave MoM dataset:

- `linear_ridge`: first-order response-surface model;
- `quadratic_ridge`: second-order response-surface model;
- `rbf_kernel_ridge`: Gaussian radial-basis/kernel surrogate;
- `knn_distance_weighted`: local interpolation baseline;
- `forward_mlp_ensemble`: the proposed neural ensemble surrogate.

Outputs:

results/surrogate_family_comparison.csv
results/surrogate_family_comparison_summary.json

The comparison reports RMSE, MAE, maximum absolute error, R2 and runtime.  This
helps justify why the forward MLP ensemble is used instead of only a classical
response surface, RBF, or nearest-neighbour surrogate.

## 2. Why use separate forward and inverse MLPs?

The forward MLP learns the well-posed map:

antenna geometry -> MoM-computed impedance spectrum

It is used for response prediction, uncertainty estimation, active learning and
fast inverse search.

The inverse MLP learns the bad-posed map:

desired impedance spectrum -> candidate geometry

Because many different geometries can produce similar impedance spectra, the
inverse MLP is not used as final proof.  It is only a fast seed generator. Every
inverse design is re-evaluated by the full-wave MoM solver and can be refined
stochastically.

## 3. Inverse MLP comparison

The project now compares:

- `inverse_mlp_only`;
- `inverse_mlp_plus_stochastic_refinement`;
- `stochastic_refinement_from_dataset_best`;
- `direct_nelder_mead_from_dataset_best`.

Outputs:

results/inverse_design_comparison.csv
results/inverse_design_comparison_summary.json

This directly tests whether the inverse MLP adds useful information beyond
stochastic refinement or direct optimization alone.

## 4. Commands to run:

python main.py --mode synthesize --profile quick --force-dataset --run-benchmarks

python main.py --mode synthesize --profile standard --run-benchmarks

If runtime is too high:

python main.py --mode synthesize --profile standard --run-benchmarks --disable-inverse-comparison

or:

python main.py --mode synthesize --profile standard --run-benchmarks --disable-surrogate-comparison

