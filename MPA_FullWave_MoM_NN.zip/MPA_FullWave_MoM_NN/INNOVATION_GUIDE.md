# Innovation guide 

## Baseline method

A conventional surrogate flow is:

```text
sample designs -> full-wave solver -> NN -> inverse search -> validate best design
```

This project extends it to:

```text
sample designs -> full-wave spectral MoM -> NN ensemble
       -> active learning based on uncertainty + objective + diversity
       -> inverse search
       -> full-wave validation of top candidates
       -> tolerance-aware robust re-ranking
       -> HFSS export
```

## Active learning acquisition

For a design vector `x`, the ensemble predicts the impedance spectrum target. The acquisition value is:

```text
A(x) = J_pred(x) - beta * uncertainty(x) - eta * distance_to_dataset(x)
```

Lower `A(x)` is better. This deliberately balances:

- exploitation: low predicted matching objective;
- exploration: high NN uncertainty;
- diversity: distance from existing samples.

The selected designs are then evaluated by the same full-wave MoM solver and appended to the training dataset.

## Robust tolerance objective

The nominal design is not enough for FR4 PCB fabrication. The robust score uses full-wave MoM under perturbations:

```text
J_robust = mean(J) + w_std * std(J) + w_worst * max(J)
```

Perturbations include:

- patch length and width;
- feed x and y offsets;
- terminal/contact span;
- dielectric constant eps_r;
- substrate height.

This makes the final selected design less sensitive to fabrication tolerances.



