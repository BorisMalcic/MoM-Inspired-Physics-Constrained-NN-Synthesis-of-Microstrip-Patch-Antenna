from __future__ import annotations
import numpy as np
from scipy.optimize import minimize

from dataset import latin_hypercube, clip_design, geometry_from_design, design_bounds
from metrics import impedance_from_target, objective_from_impedance, objective_from_results
from mom.port import port_reference_impedance


def _diverse_top_candidates(pool, scores, n, cfg):
    bounds = design_bounds(cfg)
    scale = bounds[:, 1] - bounds[:, 0] + 1e-15
    order = np.argsort(scores)
    selected = []
    for idx in order:
        candidate = pool[idx]
        if all(np.linalg.norm((candidate - q) / scale) > 0.025 for q in selected):
            selected.append(candidate)
        if len(selected) >= n:
            break
    if len(selected) < n:
        for idx in order[:n]:
            if len(selected) >= n:
                break
            selected.append(pool[idx])
    return selected[:n]


def synthesize(cfg, solver, surrogate):
    """Surrogate inverse search followed by full-wave MoM validation/refinement."""
    zref = port_reference_impedance(cfg.port)
    pool = latin_hypercube(cfg.nn.candidate_pool, cfg, cfg.nn.seed + 999)
    mean, std = surrogate.predict(pool)
    scores = []
    for mu, sigma in zip(mean, std):
        z = impedance_from_target(mu, zref)
        scores.append(objective_from_impedance(z, zref) + 0.04 * float(np.sqrt(np.mean(sigma**2))))
    selected = _diverse_top_candidates(pool, np.asarray(scores), cfg.nn.fullwave_candidates, cfg)

    validated = []
    for idx, x in enumerate(selected, 1):
        result = solver.sweep(geometry_from_design(x, cfg))
        score = objective_from_results(result)
        print(f"full-wave candidate {idx:2d}/{len(selected)} score={score:.6f}")
        validated.append((score, x, result))
    validated.sort(key=lambda q: q[0])
    best_score, best_x, best_result = validated[0]

    bounds = design_bounds(cfg)
    evaluations = 0

    def direct(q):
        nonlocal evaluations
        evaluations += 1
        x = clip_design(q, cfg)
        result = solver.sweep(geometry_from_design(x, cfg))
        return objective_from_results(result)

    if cfg.nn.local_refine_evaluations > 0:
        options = {
            "maxfev": cfg.nn.local_refine_evaluations,
            "maxiter": cfg.nn.local_refine_evaluations,
            "xatol": 1e-5,
            "fatol": 1e-4,
            "disp": False,
        }
        res = minimize(direct, best_x, method="Nelder-Mead", options=options)
        candidate = clip_design(res.x, cfg)
        result = solver.sweep(geometry_from_design(candidate, cfg))
        score = objective_from_results(result)
        print(f"local full-wave refinement score={score:.6f} evaluations={evaluations}")
        validated.append((score, candidate, result))
        validated.sort(key=lambda q: q[0])
        if score < best_score:
            best_score, best_x, best_result = score, candidate, result

    return best_x, best_result, validated
