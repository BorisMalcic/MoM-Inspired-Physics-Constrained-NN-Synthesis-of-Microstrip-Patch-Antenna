from __future__ import annotations
from time import perf_counter
import numpy as np

from dataset import latin_hypercube, clip_design, geometry_from_design, design_bounds
from metrics import objective_from_results, band_metrics


def _evaluate(design, cfg, solver):
    t0 = perf_counter()
    result = solver.sweep(geometry_from_design(design, cfg))
    seconds = perf_counter() - t0
    score = objective_from_results(result)
    return float(score), result, seconds


def random_search_direct(cfg, solver, evaluations=None, seed=None):
    n = int(cfg.benchmark.random_search_evaluations if evaluations is None else evaluations)
    seed = cfg.benchmark.seed if seed is None else seed
    pool = latin_hypercube(n, cfg, seed)
    records = []
    best = None
    for i, x in enumerate(pool, 1):
        score, result, seconds = _evaluate(x, cfg, solver)
        rec = {"method": "direct_random_search", "eval": i, "score": score, "seconds": seconds, "design": x, "result": result}
        records.append(rec)
        if best is None or score < best["score"]:
            best = rec
    return best, records


def genetic_algorithm_direct(cfg, solver, seed=None):
    ga = cfg.ga
    rng = np.random.default_rng(ga.seed if seed is None else seed)
    bounds = design_bounds(cfg)
    span = bounds[:, 1] - bounds[:, 0]
    pop = latin_hypercube(ga.population, cfg, ga.seed if seed is None else seed)
    records = []
    best = None
    eval_count = 0

    def eval_pop(population, generation):
        nonlocal best, eval_count
        scored = []
        for row in population:
            eval_count += 1
            score, result, seconds = _evaluate(row, cfg, solver)
            rec = {
                "method": "direct_ga",
                "generation": int(generation),
                "eval": int(eval_count),
                "score": float(score),
                "seconds": float(seconds),
                "design": row.copy(),
                "result": result,
            }
            records.append(rec)
            scored.append((score, row.copy(), result))
            if best is None or score < best["score"]:
                best = rec
        scored.sort(key=lambda t: t[0])
        return scored

    scored = eval_pop(pop, 0)
    for generation in range(1, int(ga.generations) + 1):
        elite_n = max(1, int(round(ga.elite_fraction * len(scored))))
        elites = [x for _, x, _ in scored[:elite_n]]
        children = list(elites)
        parent_pool = [x for _, x, _ in scored[: max(elite_n, len(scored)//2)]]
        while len(children) < ga.population:
            p1 = parent_pool[rng.integers(0, len(parent_pool))]
            p2 = parent_pool[rng.integers(0, len(parent_pool))]
            if rng.random() < ga.crossover_probability:
                alpha = rng.random(len(p1))
                child = alpha * p1 + (1.0 - alpha) * p2
            else:
                child = p1.copy()
            child += rng.normal(0.0, ga.mutation_sigma_fraction, size=len(child)) * span
            children.append(clip_design(child, cfg))
        scored = eval_pop(np.asarray(children, float), generation)
    return best, records


def record_to_public(rec):
    m = band_metrics(rec["result"])
    d = np.asarray(rec["design"], float)
    return {
        "method": rec["method"],
        "score": float(rec["score"]),
        "seconds": float(rec["seconds"]),
        "patch_length_mm": float(d[0] * 1e3),
        "patch_width_mm": float(d[1] * 1e3),
        "feed_x_fraction": float(d[2]),
        "feed_y_mm": float(d[3] * 1e3),
        "terminal_span_y_mm": float(d[4] * 1e3),
        "worst_s11_db": float(m["worst_s11_db"]),
        "center_re_z_ohm": float(m["center_re_z_ohm"]),
        "center_im_z_ohm": float(m["center_im_z_ohm"]),
        "center_s11_db": float(m["center_s11_db"]),
        "band_target_pass": bool(m["band_target_pass"]),
    }
