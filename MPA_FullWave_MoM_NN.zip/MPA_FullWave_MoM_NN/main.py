from __future__ import annotations
import argparse
from pathlib import Path

from config import profile_config, smoke_config
from mom.solver import SpectralMoMSolver
from dataset import build_dataset, geometry_from_design
from active_learning import active_learning_loop
from nn import EnsembleSurrogate
from optimization import synthesize
from io_utils import save_all
from convergence import run_convergence
from robustness import choose_robust_candidate, save_robustness_report, evaluate_robustness
from cross_validation import cross_validate_surrogate
from benchmarks import run_benchmark_suite
from statistical_evaluation import make_statistical_report
from surrogate_baselines import compare_surrogate_families
from inverse_models import compare_inverse_design_methods
from experiment_tracking import TRACKER, timer


def run_single(cfg, outdir="results"):
    solver = SpectralMoMSolver(cfg, cfg.sweep.display_frequencies_hz)
    result = solver.sweep(cfg.geometry, keep_center_coefficients=True)
    center = min(range(len(result)), key=lambda i: abs(result[i].frequency_hz - 2.44175e9))
    coeff = result[center].coefficients
    save_all(cfg, cfg.geometry, result, solver.modes, coeff, outdir)
    for r in result:
        print(
            f"{r.frequency_hz/1e9:.5f} GHz  Zin={r.zin_ohm.real:.4f}{r.zin_ohm.imag:+.4f}j  "
            f"S11={r.s11_db:.3f} dB  VSWR={r.vswr:.3f}"
        )


def run_synthesis(cfg, force_dataset=False, disable_active=False, disable_robust=False, disable_cv=False, run_benchmarks=False, disable_surrogate_compare=False, disable_inverse_compare=False):
    out = Path("results")
    out.mkdir(exist_ok=True)
    TRACKER.reset()
    with timer("total_synthesis_workflow", profile=cfg.profile_name):
        synth_solver = SpectralMoMSolver(cfg, cfg.sweep.synthesis_frequencies_hz)
        with timer("dataset_generation_or_load"):
            X, Y = build_dataset(cfg, synth_solver, out / "fullwave_dataset.npz", force=force_dataset)

        if disable_active:
            with timer("surrogate_training_final"):
                surrogate = EnsembleSurrogate(cfg.nn).fit(X, Y)
            active_records = []
        else:
            with timer("active_learning_loop"):
                X, Y, surrogate, active_records = active_learning_loop(cfg, synth_solver, X, Y, out)

        if not disable_cv:
            with timer("kfold_cross_validation"):
                cross_validate_surrogate(cfg, X, Y, out)

        # Extra reviewer-oriented comparisons are tied to --run-benchmarks by default
        # so normal synthesis remains affordable.
        if run_benchmarks and not disable_surrogate_compare and cfg.surrogate_comparison.enabled:
            with timer("surrogate_family_comparison"):
                compare_surrogate_families(cfg, X, Y, out)

        if run_benchmarks and not disable_inverse_compare and cfg.inverse_comparison.enabled:
            with timer("inverse_mlp_comparison"):
                compare_inverse_design_methods(cfg, synth_solver, X, Y, out)

        with timer("nn_inverse_search_and_fullwave_validation"):
            best_x, best_result, validated = synthesize(cfg, synth_solver, surrogate)

        robust_report = None
        robust_ranking = []
        if not disable_robust and cfg.tolerance.enabled:
            with timer("robust_tolerance_reranking"):
                best_x, best_result, _nominal_score, robust_report, robust_ranking = choose_robust_candidate(
                    validated, cfg, synth_solver
                )

        if run_benchmarks and cfg.benchmark.enabled:
            with timer("method_runtime_benchmark_suite"):
                run_benchmark_suite(cfg, synth_solver, best_x, best_result, out)

        geometry = geometry_from_design(best_x, cfg)
        display_solver = SpectralMoMSolver(cfg, cfg.sweep.display_frequencies_hz)
        with timer("final_display_sweep"):
            display_result = display_solver.sweep(geometry, keep_center_coefficients=True)
        center = min(range(len(display_result)), key=lambda i: abs(display_result[i].frequency_hz - 2.44175e9))
        save_all(
            cfg,
            geometry,
            display_result,
            display_solver.modes,
            display_result[center].coefficients,
            out,
            surrogate.histories,
            best_x,
            validated,
        )
        save_robustness_report(robust_report, robust_ranking, out)
        TRACKER.save(out)
        make_statistical_report(out)

    print("Best full-wave MoM design:")
    print(f"  L={geometry.patch_length_m*1e3:.6f} mm  W={geometry.patch_width_m*1e3:.6f} mm")
    print(f"  feed=({geometry.feed_x_m*1e3:.6f},{geometry.feed_y_m*1e3:.6f}) mm")
    print(f"  terminal span={geometry.terminal_span_y_m*1e3:.6f} mm")
    if robust_report:
        print(
            f"Robust score={robust_report['robust_score']:.6f}, "
            f"band-pass probability={robust_report['band_pass_probability']:.2f}"
        )


def run_robust_only(cfg):
    solver = SpectralMoMSolver(cfg, cfg.sweep.synthesis_frequencies_hz)
    # Internal design-vector convention:
    # [patch_length_m, patch_width_m, feed_x_fraction, feed_y_m, terminal_span_y_m].
    # cfg.geometry.feed_x_m is an absolute distance in meters, so it is divided
    # by patch_length_m here.  geometry_from_design() converts it back to meters.
    design = [
        cfg.geometry.patch_length_m,
        cfg.geometry.patch_width_m,
        cfg.geometry.feed_x_m / cfg.geometry.patch_length_m,
        cfg.geometry.feed_y_m,
        cfg.geometry.terminal_span_y_m,
    ]
    report = evaluate_robustness(design, cfg, solver)
    save_robustness_report(report, [], "results_robust")
    print(f"Robust score={report['robust_score']:.6f}")
    print(f"Band-pass probability={report['band_pass_probability']:.2f}")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--mode", choices=["smoke", "single", "synthesize", "converge", "robust"], default="synthesize")
    p.add_argument("--profile", choices=["quick", "standard", "publication"], default="quick")
    p.add_argument("--force-dataset", action="store_true")
    p.add_argument("--disable-active", action="store_true", help="Disable active-learning enrichment.")
    p.add_argument("--disable-robust", action="store_true", help="Disable tolerance-aware robust re-ranking.")
    p.add_argument("--disable-cv", action="store_true", help="Skip k-fold cross-validation report.")
    p.add_argument("--run-benchmarks", action="store_true", help="Run direct random-search, GA, surrogate-family, and inverse-MLP comparison baselines.")
    p.add_argument("--disable-surrogate-comparison", action="store_true", help="Skip comparison against RBF/polynomial/kNN surrogate families when benchmarks are enabled.")
    p.add_argument("--disable-inverse-comparison", action="store_true", help="Skip inverse-MLP vs refinement-only comparison when benchmarks are enabled.")
    a = p.parse_args()
    cfg = smoke_config() if a.mode == "smoke" else profile_config(a.profile)
    if a.mode in ("smoke", "single"):
        run_single(cfg, "results_smoke" if a.mode == "smoke" else "results")
    elif a.mode == "synthesize":
        run_synthesis(cfg, a.force_dataset, a.disable_active, a.disable_robust, a.disable_cv, a.run_benchmarks, a.disable_surrogate_comparison, a.disable_inverse_comparison)
    elif a.mode == "robust":
        run_robust_only(cfg)
    else:
        run_convergence(cfg)


if __name__ == "__main__":
    main()
