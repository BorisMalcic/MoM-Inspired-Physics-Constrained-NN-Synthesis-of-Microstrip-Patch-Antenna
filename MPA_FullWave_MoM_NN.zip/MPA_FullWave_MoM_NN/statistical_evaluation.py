from __future__ import annotations
from pathlib import Path
import json
import numpy as np


def _summ(values):
    values = np.asarray(values, float)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return None
    std = float(np.std(values, ddof=1)) if values.size > 1 else 0.0
    return {
        "n": int(values.size),
        "mean": float(np.mean(values)),
        "std": std,
        "min": float(np.min(values)),
        "max": float(np.max(values)),
        "ci95_half_width": float(1.96 * std / np.sqrt(values.size)),
    }


def make_statistical_report(outdir):
    """Collect CV, robust tolerance, active-learning and benchmark summaries."""
    out = Path(outdir)
    report = {"files_available": {}}
    for name in [
        "cross_validation_summary.json",
        "robust_tolerance_summary.json",
        "method_comparison_summary.json",
        "surrogate_family_comparison_summary.json",
        "inverse_design_comparison_summary.json",
        "runtime_summary.json",
    ]:
        path = out / name
        report["files_available"][name] = path.exists()
        if path.exists():
            try:
                report[name[:-5]] = json.loads(path.read_text())
            except Exception as exc:
                report[name[:-5]] = {"error": str(exc)}

    # Additional active-learning statistics from CSV if present.
    path = out / "active_learning_history.csv"
    if path.exists():
        import csv
        rows = []
        with path.open() as h:
            for r in csv.DictReader(h):
                rows.append(r)
        report["active_learning"] = {"records": len(rows)}
        for key in ["predicted_objective", "actual_objective", "ensemble_uncertainty", "target_rmse_vs_surrogate"]:
            vals = []
            for r in rows:
                try:
                    vals.append(float(r[key]))
                except Exception:
                    pass
            report["active_learning"][key] = _summ(vals)

    (out / "statistical_evaluation.json").write_text(json.dumps(report, indent=2))
    return report
