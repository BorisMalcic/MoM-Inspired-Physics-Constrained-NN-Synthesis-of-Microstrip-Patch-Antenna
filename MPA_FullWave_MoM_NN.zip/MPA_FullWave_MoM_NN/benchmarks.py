from __future__ import annotations
from pathlib import Path
from time import perf_counter
import csv, json
import numpy as np

from optimization.genetic_algorithm import genetic_algorithm_direct, random_search_direct, record_to_public
from metrics import band_metrics, objective_from_results
from dataset import geometry_from_design
from experiment_tracking import TRACKER


def _ci95(values):
    values = np.asarray(values, float)
    values = values[np.isfinite(values)]
    if values.size == 0:
        return {"mean": float("nan"), "std": float("nan"), "ci95_half_width": float("nan")}
    std = float(np.std(values, ddof=1)) if values.size > 1 else 0.0
    return {"mean": float(np.mean(values)), "std": std, "ci95_half_width": float(1.96 * std / np.sqrt(values.size))}


def save_method_comparison(records, outdir):
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    if not records:
        return {"enabled": False}
    fields = list(records[0].keys())
    with (out / "method_comparison.csv").open("w", newline="") as h:
        w = csv.DictWriter(h, fieldnames=fields)
        w.writeheader()
        for r in records:
            w.writerow(r)
    methods = sorted(set(r["method"] for r in records))
    summary = {"enabled": True, "methods": {}}
    for method in methods:
        rows = [r for r in records if r["method"] == method]
        summary["methods"][method] = {
            "runs": len(rows),
            "score": _ci95([r["score"] for r in rows]),
            "runtime_seconds": _ci95([r["total_seconds"] for r in rows]),
            "worst_s11_db": _ci95([r["worst_s11_db"] for r in rows]),
            "center_s11_db": _ci95([r["center_s11_db"] for r in rows]),
            "band_pass_rate": float(np.mean([bool(r["band_target_pass"]) for r in rows])),
        }
    (out / "method_comparison_summary.json").write_text(json.dumps(summary, indent=2))
    return summary


def run_benchmark_suite(cfg, solver, nn_best_design, nn_best_result, outdir):
    """Compare NN-assisted result against direct random search and GA baselines.

    All baseline objective evaluations are full-wave MoM sweeps.  This is kept
    optional because GA/direct search can be expensive for standard/publication
    profiles.
    """
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    records = []

    # Runtime for the active-NN method is the workflow time accumulated before
    # this benchmark stage: dataset generation/load, active learning, CV, inverse
    # search/full-wave validation, and robust re-ranking when enabled.
    nn_time = sum(
        e.seconds for e in TRACKER.events
        if e.name in {
            "dataset_generation_or_load",
            "active_learning_loop",
            "surrogate_training_final",
            "kfold_cross_validation",
            "nn_inverse_search_and_fullwave_validation",
            "robust_tolerance_reranking",
        }
    )
    nn_score = objective_from_results(nn_best_result)
    m = band_metrics(nn_best_result)
    records.append({
        "method": "active_nn_surrogate",
        "repeat": 1,
        "score": float(nn_score),
        "total_seconds": float(nn_time),
        "best_eval_seconds": 0.0,
        "patch_length_mm": float(nn_best_design[0] * 1e3),
        "patch_width_mm": float(nn_best_design[1] * 1e3),
        "feed_x_fraction": float(nn_best_design[2]),
        "feed_y_mm": float(nn_best_design[3] * 1e3),
        "terminal_span_y_mm": float(nn_best_design[4] * 1e3),
        "worst_s11_db": float(m["worst_s11_db"]),
        "center_re_z_ohm": float(m["center_re_z_ohm"]),
        "center_im_z_ohm": float(m["center_im_z_ohm"]),
        "center_s11_db": float(m["center_s11_db"]),
        "band_target_pass": bool(m["band_target_pass"]),
    })

    repeats = max(1, int(cfg.benchmark.repeats))
    for rep in range(repeats):
        t0 = perf_counter()
        best, _ = random_search_direct(cfg, solver, seed=cfg.benchmark.seed + 31 * rep)
        public = record_to_public(best)
        public.update({"repeat": rep + 1, "total_seconds": float(perf_counter() - t0), "best_eval_seconds": public.pop("seconds")})
        records.append(public)

    if cfg.ga.enabled:
        for rep in range(repeats):
            t0 = perf_counter()
            best, _ = genetic_algorithm_direct(cfg, solver, seed=cfg.ga.seed + 47 * rep)
            public = record_to_public(best)
            public.update({"repeat": rep + 1, "total_seconds": float(perf_counter() - t0), "best_eval_seconds": public.pop("seconds")})
            records.append(public)

    return save_method_comparison(records, out)
