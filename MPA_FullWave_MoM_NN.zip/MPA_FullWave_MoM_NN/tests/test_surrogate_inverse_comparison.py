import numpy as np
from config import smoke_config
from surrogate_baselines import PolynomialRidge, RBFKernelRidge, KNNRegressor
from inverse_models import desired_response_target, InverseMLPEnsemble


def test_baseline_surrogates_shapes():
    rng = np.random.default_rng(1)
    X = rng.normal(size=(8, 5))
    Y = rng.normal(size=(8, 4))
    for model in [PolynomialRidge(1), PolynomialRidge(2), RBFKernelRidge(), KNNRegressor(k=3)]:
        model.fit(X, Y)
        pred = model.predict(X[:2])
        assert pred.shape == (2, 4)
        assert np.all(np.isfinite(pred))


def test_inverse_mlp_shapes():
    cfg = smoke_config()
    nfreq = len(cfg.sweep.synthesis_frequencies_hz)
    rng = np.random.default_rng(2)
    X = rng.uniform(0.0, 1.0, size=(6, 5))
    Y = rng.normal(size=(6, 2 * nfreq))
    inv = InverseMLPEnsemble(cfg).fit(X, Y)
    target = desired_response_target(cfg)
    mean, std, members = inv.predict(target)
    assert mean.shape == (5,)
    assert std.shape == (5,)
    assert members.shape[1] == 5
    assert np.all(np.isfinite(mean))
