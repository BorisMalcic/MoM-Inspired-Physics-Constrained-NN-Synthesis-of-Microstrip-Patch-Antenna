from pathlib import Path
import numpy as np

from config import smoke_config
from mom.solver import SpectralMoMSolver
from dataset import build_dataset, geometry_from_design
from active_learning import active_learning_loop
from robustness import evaluate_robustness


def test_active_learning_loop_runs(tmp_path):
    cfg = smoke_config()
    solver = SpectralMoMSolver(cfg, cfg.sweep.synthesis_frequencies_hz)
    X, Y = build_dataset(cfg, solver, tmp_path / "dataset.npz", force=True)
    X2, Y2, surrogate, records = active_learning_loop(cfg, solver, X, Y, tmp_path)
    assert X2.shape[0] >= X.shape[0]
    assert Y2.shape[0] == X2.shape[0]
    assert (tmp_path / "active_learning_history.csv").exists()
    mean, std = surrogate.predict(X2[:1])
    assert np.all(np.isfinite(mean))
    assert np.all(np.isfinite(std))


def test_robustness_report_runs():
    cfg = smoke_config()
    solver = SpectralMoMSolver(cfg, cfg.sweep.synthesis_frequencies_hz)
    design = np.array([
        cfg.geometry.patch_length_m,
        cfg.geometry.patch_width_m,
        cfg.geometry.feed_x_m / cfg.geometry.patch_length_m,
        cfg.geometry.feed_y_m,
        cfg.geometry.terminal_span_y_m,
    ])
    report = evaluate_robustness(design, cfg, base_solver=solver, samples=1, seed=1)
    assert report["enabled"] is True
    assert report["robust_score"] > 0
    assert 0.0 <= report["band_pass_probability"] <= 1.0
