import numpy as np
from config import smoke_config
from mom.basis import build_modes
from mom.port import (
    excitation_vector,
    input_impedance,
    coax_characteristic_impedance,
    coax_eps_r_for_impedance,
    port_reference_impedance,
)


def test_port_has_no_hidden_scale():
    c = smoke_config()
    m = build_modes(c.basis)
    v = excitation_vector(c.geometry, m, c.port)
    assert np.any(np.abs(v) > 0)
    z = input_impedance(v, np.ones(len(v), complex), 1.0)
    assert np.isfinite(z)


def test_sma_coax_impedance_is_50_ohm():
    c = smoke_config()
    z0 = coax_characteristic_impedance(
        c.port.inner_conductor_radius_m,
        c.port.shield_inner_radius_m,
        c.port.coax_dielectric_eps_r,
    )
    assert abs(z0 - 50.0) < 1e-6
    assert abs(port_reference_impedance(c.port) - 50.0) < 1e-6


def test_eps_r_formula_for_given_coax_radii():
    eps = coax_eps_r_for_impedance(0.35e-3, 1.20e-3, 50.0)
    assert 2.18 < eps < 2.19
