from config import smoke_config
from mom.solver import SpectralMoMSolver

def test_smoke_solver():
    c=smoke_config();s=SpectralMoMSolver(c);r=s.sweep(c.geometry)
    assert len(r)==1;assert abs(r[0].zin_ohm)<1e8
