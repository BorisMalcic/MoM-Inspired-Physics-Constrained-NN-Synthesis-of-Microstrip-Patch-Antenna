import numpy as np
from config import smoke_config
from mom.green import grounded_slab_surface_dyadic

def test_green_reciprocal_and_finite():
    c=smoke_config();kx=np.array([10.,20.],complex);ky=np.array([3.,-4.],complex);g=grounded_slab_surface_dyadic(kx,ky,2.44e9,c.material)
    assert np.isfinite(g).all();assert np.allclose(g[:,0,1],g[:,1,0])
