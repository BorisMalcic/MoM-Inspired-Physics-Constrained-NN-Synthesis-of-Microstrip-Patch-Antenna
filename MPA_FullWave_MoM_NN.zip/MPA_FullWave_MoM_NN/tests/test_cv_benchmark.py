from pathlib import Path
import numpy as np

from config import smoke_config
from cross_validation import cross_validate_surrogate
from optimization.genetic_algorithm import genetic_algorithm_direct, random_search_direct
from experiment_tracking import TRACKER


class DummySolver:
    def sweep(self, geometry):
        # Minimal PointResult-like objects for objective/band metrics.
        class R:
            pass
        r = R()
        r.frequency_hz = 2.44175e9
        # Smooth synthetic dependence on geometry, only for test speed.
        z = 50 + 1j * 0
        r.zin_ohm = complex(z)
        r.s11_db = -80.0
        r.vswr = 1.0
        r.condition_number = 1.0
        return [r]


def test_cross_validation_outputs(tmp_path):
    cfg = smoke_config()
    X = np.random.default_rng(1).random((8, 5))
    Y = np.random.default_rng(2).random((8, 2))
    summary, records = cross_validate_surrogate(cfg, X, Y, tmp_path)
    assert summary["enabled"]
    assert records
    assert (tmp_path / "cross_validation_metrics.csv").exists()
    assert (tmp_path / "cross_validation_summary.json").exists()


def test_direct_baselines_return_records():
    cfg = smoke_config()
    solver = DummySolver()
    best_r, records_r = random_search_direct(cfg, solver, evaluations=2, seed=1)
    best_g, records_g = genetic_algorithm_direct(cfg, solver, seed=1)
    assert best_r["score"] >= 0.0
    assert len(records_r) == 2
    assert best_g["score"] >= 0.0
    assert len(records_g) >= cfg.ga.population


def test_runtime_tracker_summary(tmp_path):
    TRACKER.reset()
    TRACKER.add_mom_sweep(0.1, 3, 5)
    TRACKER.save(tmp_path)
    assert TRACKER.summary()["mom_point_solves"] == 3
    assert (tmp_path / "runtime_summary.json").exists()
