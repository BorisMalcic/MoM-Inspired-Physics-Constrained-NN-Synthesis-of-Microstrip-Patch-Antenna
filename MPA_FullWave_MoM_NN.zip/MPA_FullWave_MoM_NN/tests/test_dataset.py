from config import smoke_config
from dataset import latin_hypercube,geometry_from_design

def test_design_mapping():
    c=smoke_config();x=latin_hypercube(3,c,1)
    for row in x:
        g=geometry_from_design(row,c);assert g.patch_length_m>0 and g.terminal_span_y_m>0
