import numpy as np
from config import smoke_config
from mom.basis import build_modes,fourier_matrix

def test_basis_fourier_finite():
    c=smoke_config();m=build_modes(c.basis);f=fourier_matrix(np.array([0.,10.]),np.array([0.,5.]),.028,.042,m)
    assert f.shape==(2,len(m),2);assert np.isfinite(f).all()
