"""Entire-domain current basis functions and exact Fourier transforms."""
from __future__ import annotations
from dataclasses import dataclass
from math import pi
import numpy as np


@dataclass(frozen=True)
class EntireDomainMode:
    orientation: str
    qx_index: int
    qy_index: int


def build_modes(cfg):
    modes = []
    for m in range(cfg.mx_x):
        for n in range(cfg.ny_x):
            modes.append(EntireDomainMode("x", 2 * m + 1, 2 * n))
    for m in range(cfg.mx_y):
        for n in range(cfg.ny_y):
            modes.append(EntireDomainMode("y", 2 * m, 2 * n + 1))
    return modes


def _half_interval_exp_cos_integral(k, length, q):
    """Integral of cos(q x) exp(j k x) on [-length/2,length/2]."""
    k = np.asarray(k, dtype=complex)
    out = np.empty_like(k)
    p1 = k + q
    p2 = k - q

    def term(p):
        z = p * length / 2.0
        ans = np.empty_like(p)
        mask = np.abs(p) < 1e-11
        ans[mask] = length / 2.0
        ans[~mask] = np.sin(z[~mask]) / p[~mask]
        return ans

    out[:] = term(p1) + term(p2)
    return out


def fourier_matrix(kx, ky, length, width, modes):
    """Return F[p,n,component] = integral f_n(r) exp(j k.r) dS."""
    f = np.zeros((len(kx), len(modes), 2), dtype=complex)
    for idx, mode in enumerate(modes):
        qx = mode.qx_index * pi / length
        qy = mode.qy_index * pi / width
        value = (
            _half_interval_exp_cos_integral(kx, length, qx)
            * _half_interval_exp_cos_integral(ky, width, qy)
        )
        if mode.orientation == "x":
            f[:, idx, 0] = value / width
        else:
            f[:, idx, 1] = value / length
    return f


def mode_mass_diagonal(length, width, modes):
    """Analytic Galerkin mass integral integral f_m dot f_n dS (diagonal)."""
    values = []
    for mode in modes:
        ix = length if mode.qx_index == 0 else length / 2.0
        iy = width if mode.qy_index == 0 else width / 2.0
        norm = 1.0 / width**2 if mode.orientation == "x" else 1.0 / length**2
        values.append(ix * iy * norm)
    return np.asarray(values, dtype=float)


def evaluate_current(x, y, length, width, modes, coefficients):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    jx = np.zeros(np.broadcast(x, y).shape, dtype=complex)
    jy = np.zeros_like(jx)
    for mode, coefficient in zip(modes, coefficients):
        qx = mode.qx_index * pi / length
        qy = mode.qy_index * pi / width
        value = np.cos(qx * x) * np.cos(qy * y)
        if mode.orientation == "x":
            jx += coefficient * value / width
        else:
            jy += coefficient * value / length
    return jx, jy
