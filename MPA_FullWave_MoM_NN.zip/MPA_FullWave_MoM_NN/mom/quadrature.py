"""Stable real-axis spectral quadrature split around branch regions."""
from __future__ import annotations
from math import pi
import numpy as np
from .constants import C0, MU0, EPS0


def spectral_quadrature(freq_hz, eps_r, loss_tan, cfg):
    omega = 2.0 * pi * freq_hz
    k0 = omega / C0
    eps1 = EPS0 * eps_r * (1.0 - 1j * loss_tan)
    k1 = omega * np.sqrt(MU0 * eps1)
    b0 = float(abs(k0))
    b1 = float(abs(np.real(k1)))
    guard = cfg.branch_guard_fraction
    kmax = cfg.k_rho_max_factor * b0

    anchors = [
        0.0,
        0.72 * b0,
        (1.0 - 4 * guard) * b0,
        (1.0 - guard) * b0,
        (1.0 + guard) * b0,
        (1.0 + 4 * guard) * b0,
        1.25 * b0,
    ]
    if b1 > 1.3 * b0:
        anchors += [
            0.72 * b1,
            (1.0 - 4 * guard) * b1,
            (1.0 - guard) * b1,
            (1.0 + guard) * b1,
            (1.0 + 4 * guard) * b1,
            1.25 * b1,
        ]
    start = max(anchors)
    if start < kmax:
        anchors += list(np.geomspace(max(start, 1.26 * b0), kmax, 8))
    anchors = sorted(set(max(0.0, min(float(a), kmax)) for a in anchors))
    if anchors[-1] < kmax:
        anchors.append(kmax)

    xg, wg = np.polynomial.legendre.leggauss(cfg.radial_order_per_segment)
    kr_parts, wr_parts = [], []
    for left, right in zip(anchors[:-1], anchors[1:]):
        if right <= left:
            continue
        kr_parts.append(0.5 * (right - left) * xg + 0.5 * (left + right))
        wr_parts.append(0.5 * (right - left) * wg)
    kr = np.concatenate(kr_parts)
    wr = np.concatenate(wr_parts)

    phi = 2.0 * pi * np.arange(cfg.angular_samples) / cfg.angular_samples
    KR, PHI = np.meshgrid(kr, phi, indexing="ij")
    WR, _ = np.meshgrid(wr, phi, indexing="ij")
    kx = (KR * np.cos(PHI)).ravel()
    ky = (KR * np.sin(PHI)).ravel()
    weights = (WR * KR * (2.0 * pi / cfg.angular_samples) / (2.0 * pi) ** 2).ravel()
    return kx, ky, weights
