"""Port excitation and V/I extraction for the planar spectral MoM solver.

Two port models are available:

``delta_gap``
    Original rectangular finite delta-gap terminal.

``sma_coax_50ohm``
    Idealized 50-ohm SMA/coax modal terminal.  The SMA dimensions are explicit
    user parameters.  The code computes the TEM characteristic impedance from
    the coax radii and dielectric constant and uses that value as the reference
    impedance for S-parameters.  The excitation is projected onto the planar
    patch basis through a finite circular contact/frill region around the feed.

This is not an empirical port-current scale: no coefficient is multiplied into
Zin to force matching.  A full 3-D SMA connector body is outside the planar
spectral-domain formulation and should still be validated in HFSS.
"""
from __future__ import annotations
from math import pi, log, sqrt
import numpy as np


def coax_characteristic_impedance(inner_radius_m: float, shield_inner_radius_m: float, eps_r: float) -> float:
    """TEM characteristic impedance of a lossless coaxial line.

    Z0 = 60/sqrt(eps_r) * ln(b/a), where a is inner-conductor radius and
    b is shield inner radius.
    """
    a = float(inner_radius_m)
    b = float(shield_inner_radius_m)
    er = float(eps_r)
    if not (a > 0.0 and b > a and er > 0.0):
        raise ValueError("Invalid coax dimensions or dielectric constant")
    return 60.0 / sqrt(er) * log(b / a)


def coax_eps_r_for_impedance(inner_radius_m: float, shield_inner_radius_m: float, z0_ohm: float = 50.0) -> float:
    """Dielectric constant required for a target coax impedance."""
    a = float(inner_radius_m)
    b = float(shield_inner_radius_m)
    z0 = float(z0_ohm)
    if not (a > 0.0 and b > a and z0 > 0.0):
        raise ValueError("Invalid coax dimensions or target impedance")
    return (60.0 * log(b / a) / z0) ** 2


def port_reference_impedance(port_cfg) -> float:
    if getattr(port_cfg, "port_model", "delta_gap") == "sma_coax_50ohm":
        return coax_characteristic_impedance(
            port_cfg.inner_conductor_radius_m,
            port_cfg.shield_inner_radius_m,
            port_cfg.coax_dielectric_eps_r,
        )
    return float(getattr(port_cfg, "reference_impedance_ohm", 50.0))


def _mode_value(mode, geometry, X, Y):
    qx = mode.qx_index * pi / geometry.patch_length_m
    qy = mode.qy_index * pi / geometry.patch_width_m
    amp = np.cos(qx * X) * np.cos(qy * Y)
    if mode.orientation == "x":
        return amp / geometry.patch_width_m
    return amp / geometry.patch_length_m


def _delta_gap_excitation(geometry, modes, order=18):
    gap = geometry.terminal_gap_m
    span = geometry.terminal_span_y_m
    voltage = geometry.source_voltage_v
    xg, xw = np.polynomial.legendre.leggauss(order)
    yg, yw = np.polynomial.legendre.leggauss(order)
    xs = geometry.feed_x_m + 0.5 * gap * xg
    ys = geometry.feed_y_m + 0.5 * span * yg
    wx = 0.5 * gap * xw
    wy = 0.5 * span * yw
    X, Y = np.meshgrid(xs, ys, indexing="xy")
    WW = np.outer(wy, wx)

    vector = np.zeros(len(modes), dtype=complex)
    for idx, mode in enumerate(modes):
        if mode.orientation != "x":
            continue
        basis = _mode_value(mode, geometry, X, Y)
        vector[idx] = (voltage / gap) * np.sum(WW * basis)
    return vector


def _sma_coax_terminal_excitation(geometry, port_cfg, modes):
    """Project an ideal SMA/coax modal terminal onto planar basis functions.

    The equivalent terminal is a finite circular contact/frill region around the
    inner conductor.  To avoid using a hidden scale, the total reaction is
    normalized so that a locally constant x-directed basis gives the same
    reaction as the original voltage-gap definition.  The 50-ohm behavior enters
    only through the port reference impedance and explicit coax geometry.
    """
    voltage = float(geometry.source_voltage_v)
    a = float(port_cfg.inner_conductor_radius_m)
    b = float(port_cfg.shield_inner_radius_m)
    # The modal frill/contact is allowed to extend from the inner pin toward
    # the SMA shield aperture.  By default this uses the shield inner radius,
    # limited by terminal_span_y_m/2 so the user can keep a smaller solder pad.
    contact_radius = max(a, min(0.5 * geometry.terminal_span_y_m, b * float(port_cfg.contact_radius_factor)))
    contact_radius = min(contact_radius, 0.45 * geometry.patch_width_m, 0.45 * geometry.patch_length_m)
    # The finite contact is intentionally kept local.  It is not a port-current
    # calibration; it is the physical projection area of the coax pin/solder pad.
    rg, rw = np.polynomial.legendre.leggauss(int(port_cfg.radial_order))
    phis = np.linspace(0.0, 2.0 * pi, int(port_cfg.angular_order), endpoint=False)
    # Integrate disk 0..contact_radius using r dr dphi.
    radii = 0.5 * contact_radius * (rg + 1.0)
    r_weights = 0.5 * contact_radius * rw
    phi_weight = 2.0 * pi / len(phis)

    vector = np.zeros(len(modes), dtype=complex)
    # Use a smooth x-polarized modal terminal centered at the coax pin.  This is
    # compatible with the dominant TM10 patch mode and avoids the unphysical
    # cancellation that a perfectly radial tangential field would produce in a
    # purely planar current basis.
    for r, wr in zip(radii, r_weights):
        X = geometry.feed_x_m + r * np.cos(phis)
        Y = geometry.feed_y_m + r * np.sin(phis)
        inside = (np.abs(X) <= 0.5 * geometry.patch_length_m) & (np.abs(Y) <= 0.5 * geometry.patch_width_m)
        if not np.any(inside):
            continue
        w = wr * phi_weight * r
        for idx, mode in enumerate(modes):
            if mode.orientation != "x":
                continue
            basis = _mode_value(mode, geometry, X[inside], Y[inside])
            vector[idx] += (voltage / max(2.0 * a, geometry.terminal_gap_m)) * w * np.sum(basis)
    return vector


def excitation_vector(geometry, modes, port_cfg=None, order=18):
    if port_cfg is None or getattr(port_cfg, "port_model", "delta_gap") == "delta_gap":
        return _delta_gap_excitation(geometry, modes, order=order)
    if port_cfg.port_model == "sma_coax_50ohm":
        return _sma_coax_terminal_excitation(geometry, port_cfg, modes)
    raise ValueError(f"Unknown port_model: {port_cfg.port_model!r}")


def input_impedance(excitation, coefficients, source_voltage=1.0):
    # Reaction identity: V I_port = v^H I for the normalized terminal field.
    current = np.vdot(excitation, coefficients) / complex(source_voltage)
    if not np.isfinite(current) or abs(current) < 1e-18:
        raise RuntimeError("Port current is zero or non-finite")
    return complex(source_voltage) / current
