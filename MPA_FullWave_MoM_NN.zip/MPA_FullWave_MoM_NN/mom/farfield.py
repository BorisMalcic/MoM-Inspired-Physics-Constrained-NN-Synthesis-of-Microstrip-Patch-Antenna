"""Normalized current-derived broadside pattern from solved MoM coefficients."""
from __future__ import annotations
from math import pi
import numpy as np
from .constants import C0
from .basis import fourier_matrix


def normalized_cuts(geometry, modes, coefficients, frequency_hz, theta_samples=181):
    theta = np.linspace(-pi/2, pi/2, theta_samples)
    k0 = 2*pi*frequency_hz/C0

    def cut(phi):
        kx = k0*np.sin(theta)*np.cos(phi)
        ky = k0*np.sin(theta)*np.sin(phi)
        F = fourier_matrix(-kx, -ky, geometry.patch_length_m, geometry.patch_width_m, modes)
        J = np.einsum('pnc,n->pc', F, coefficients)
        khat = np.column_stack((np.sin(theta)*np.cos(phi), np.sin(theta)*np.sin(phi), np.cos(theta)))
        J3 = np.column_stack((J, np.zeros(len(theta),complex)))
        projected = J3 - khat*np.einsum('ij,ij->i',khat,J3)[:,None]
        power = np.sum(np.abs(projected)**2,axis=1)
        power /= max(float(np.max(power)),1e-30)
        return 10*np.log10(np.maximum(power,1e-12))

    return theta*180/pi, cut(0.0), cut(pi/2)
