from math import pi
C0 = 299_792_458.0
MU0 = 4.0e-7 * pi
EPS0 = 1.0 / (MU0 * C0 * C0)
ETA0 = (MU0 / EPS0) ** 0.5
