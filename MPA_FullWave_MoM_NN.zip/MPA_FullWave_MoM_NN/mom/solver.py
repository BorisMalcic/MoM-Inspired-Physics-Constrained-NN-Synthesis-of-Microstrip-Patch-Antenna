from __future__ import annotations
from dataclasses import dataclass, replace
from math import pi
from time import perf_counter
import warnings
import numpy as np
from .basis import build_modes, fourier_matrix, mode_mass_diagonal
from .quadrature import spectral_quadrature
from .green import grounded_slab_surface_dyadic
from .port import excitation_vector, input_impedance, port_reference_impedance
from .constants import MU0
from experiment_tracking import TRACKER


@dataclass
class PointResult:
    frequency_hz: float
    zin_ohm: complex
    s11_db: float
    vswr: float
    condition_number: float
    coefficients: np.ndarray | None = None


def copper_surface_impedance(freq_hz, conductivity):
    omega = 2.0 * pi * freq_hz
    return (1.0 + 1j) * np.sqrt(omega * MU0 / (2.0 * conductivity))


class SpectralMoMSolver:
    def __init__(self, cfg, frequencies_hz=None):
        self.cfg = cfg
        self.frequencies = np.asarray(
            cfg.sweep.synthesis_frequencies_hz if frequencies_hz is None else frequencies_hz,
            dtype=float,
        )
        self.modes = build_modes(cfg.basis)
        self.tables = []
        for freq in self.frequencies:
            kx, ky, weights = spectral_quadrature(
                float(freq), cfg.material.eps_r, cfg.material.loss_tan, cfg.spectral
            )
            green = grounded_slab_surface_dyadic(
                kx.astype(complex), ky.astype(complex), float(freq), cfg.material
            )
            self.tables.append((kx, ky, weights, green))

    def solve_point(self, geometry, frequency_index, keep_coefficients=False):
        freq = float(self.frequencies[frequency_index])
        kx, ky, weights, green = self.tables[frequency_index]
        f_plus = fourier_matrix(
            kx, ky, geometry.patch_length_m, geometry.patch_width_m, self.modes
        )
        f_minus = fourier_matrix(
            -kx, -ky, geometry.patch_length_m, geometry.patch_width_m, self.modes
        )
        gf = np.einsum("pab,pnb->pna", green, f_plus, optimize=True)
        matrix = np.einsum("pma,pna,p->mn", f_minus, gf, weights, optimize=True)
        matrix = 0.5 * (matrix + matrix.T)

        zs = copper_surface_impedance(freq, self.cfg.material.copper_sigma_s_per_m)
        matrix += np.diag(
            zs
            * mode_mass_diagonal(
                geometry.patch_length_m, geometry.patch_width_m, self.modes
            )
        )
        scale = max(float(np.max(np.abs(np.diag(matrix)))), 1.0)
        matrix += np.eye(len(self.modes)) * (
            self.cfg.spectral.matrix_regularization_relative * scale
        )

        excitation = excitation_vector(geometry, self.modes, self.cfg.port)
        try:
            coefficients = np.linalg.solve(matrix, excitation)
        except np.linalg.LinAlgError:
            coefficients = np.linalg.lstsq(matrix, excitation, rcond=1e-11)[0]
        condition = float(np.linalg.cond(matrix))
        if condition > self.cfg.spectral.condition_warning:
            warnings.warn(
                f"MoM matrix condition number is {condition:.3e} at {freq/1e9:.5f} GHz",
                RuntimeWarning,
            )
        zin = input_impedance(excitation, coefficients, geometry.source_voltage_v)
        zref = port_reference_impedance(self.cfg.port)
        gamma = (zin - zref) / (zin + zref)
        magnitude = float(abs(gamma))
        s11_db = float(20.0 * np.log10(max(magnitude, 1e-15)))
        vswr = float((1.0 + magnitude) / max(1.0 - magnitude, 1e-12))
        return PointResult(
            frequency_hz=freq,
            zin_ohm=zin,
            s11_db=s11_db,
            vswr=vswr,
            condition_number=condition,
            coefficients=coefficients.copy() if keep_coefficients else None,
        )

    def sweep(self, geometry, keep_center_coefficients=False):
        center = int(np.argmin(np.abs(self.frequencies - 2.44175e9)))
        t0 = perf_counter()
        result = [
            self.solve_point(
                geometry, idx, keep_coefficients=(keep_center_coefficients and idx == center)
            )
            for idx in range(len(self.frequencies))
        ]
        TRACKER.add_mom_sweep(perf_counter() - t0, len(self.frequencies), len(self.modes))
        return result
