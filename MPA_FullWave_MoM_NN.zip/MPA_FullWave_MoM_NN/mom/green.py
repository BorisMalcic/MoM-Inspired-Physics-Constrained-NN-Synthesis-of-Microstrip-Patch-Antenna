"""TE/TM spectral dyadic for a lossy dielectric slab backed by PEC."""
from __future__ import annotations
from math import pi
import numpy as np
from .constants import MU0, EPS0


def _outgoing_sqrt(value):
    kz = np.sqrt(np.asarray(value, dtype=complex))
    flip = (np.imag(kz) > 0) | ((np.abs(np.imag(kz)) < 1e-14) & (np.real(kz) < 0))
    return np.where(flip, -kz, kz)


def grounded_slab_surface_dyadic(kx, ky, freq_hz, material):
    omega = 2.0 * pi * freq_hz
    eps1 = EPS0 * material.eps_r * (1.0 - 1j * material.loss_tan)
    k0 = omega * np.sqrt(MU0 * EPS0)
    k1 = omega * np.sqrt(MU0 * eps1)
    kr2 = kx * kx + ky * ky
    kr = np.sqrt(kr2 + 0j)
    kz0 = _outgoing_sqrt(k0 * k0 - kr2)
    kz1 = _outgoing_sqrt(k1 * k1 - kr2)
    tiny = 1e-13 * max(abs(k0), 1.0)
    kz0 = np.where(np.abs(kz0) < tiny, kz0 - 1j * tiny, kz0)
    kz1 = np.where(np.abs(kz1) < tiny, kz1 - 1j * tiny, kz1)

    y0_te = kz0 / (omega * MU0)
    y0_tm = omega * EPS0 / kz0
    y1_te = kz1 / (omega * MU0)
    y1_tm = omega * eps1 / kz1
    kh = kz1 * material.substrate_h_m
    cot_kh = np.cos(kh) / (np.sin(kh) + 1e-30)
    yin_te = -1j * y1_te * cot_kh
    yin_tm = -1j * y1_tm * cot_kh
    z_te = 1.0 / (y0_te + yin_te)
    z_tm = 1.0 / (y0_tm + yin_tm)

    qx = np.ones_like(kr)
    qy = np.zeros_like(kr)
    mask = np.abs(kr) > 1e-14
    qx[mask] = kx[mask] / kr[mask]
    qy[mask] = ky[mask] / kr[mask]
    sx, sy = -qy, qx

    g = np.empty((len(kx), 2, 2), dtype=complex)
    g[:, 0, 0] = z_te * sx * sx + z_tm * qx * qx
    g[:, 0, 1] = z_te * sx * sy + z_tm * qx * qy
    g[:, 1, 0] = g[:, 0, 1]
    g[:, 1, 1] = z_te * sy * sy + z_tm * qy * qy
    return g
