from __future__ import annotations
from dataclasses import asdict, replace
from pathlib import Path
import hashlib, json
import numpy as np
from scipy.stats import qmc
from metrics import spectral_target
from mom.port import port_reference_impedance


def design_bounds(cfg):
    b=cfg.bounds
    return np.array([
        b.patch_length_m,
        b.patch_width_m,
        b.feed_x_fraction,
        b.feed_y_m,
        b.terminal_span_y_m,
    ],dtype=float)


def clip_design(x,cfg):
    x=np.asarray(x,float).copy();b=design_bounds(cfg)
    x=np.clip(x,b[:,0],b[:,1])
    # Keep terminal inside the finite patch.
    max_feed=max(0.0,0.5*x[0]-0.5*cfg.geometry.terminal_gap_m-0.2e-3)
    x[2]=min(x[2],max_feed/max(x[0],1e-12))
    max_y=max(0.0,0.5*x[1]-0.5*x[4]-0.2e-3)
    x[3]=float(np.clip(x[3],-max_y,max_y))
    return x


def geometry_from_design(x,cfg):
    x=clip_design(x,cfg)
    L,W,feed_fraction,fy,span=x
    return replace(
        cfg.geometry,
        patch_length_m=float(L),
        patch_width_m=float(W),
        feed_x_m=float(feed_fraction*L),
        feed_y_m=float(fy),
        terminal_span_y_m=float(span),
    )


def latin_hypercube(n,cfg,seed=None):
    bounds=design_bounds(cfg); sampler=qmc.LatinHypercube(d=5,seed=seed)
    u=sampler.random(n); x=qmc.scale(u,bounds[:,0],bounds[:,1])
    return np.array([clip_design(row,cfg) for row in x])


def cache_signature(cfg):
    payload={
        'profile':cfg.profile_name,
        'material':asdict(cfg.material),
        'geometry_terminal_gap_m':cfg.geometry.terminal_gap_m,
        'port':asdict(cfg.port),
        'basis':asdict(cfg.basis),
        'spectral':asdict(cfg.spectral),
        'frequencies':cfg.sweep.synthesis_frequencies_hz.tolist(),
        'bounds':asdict(cfg.bounds),
    }
    raw=json.dumps(payload,sort_keys=True).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


def build_dataset(cfg,solver,path,force=False):
    path=Path(path); signature=cache_signature(cfg)
    if path.exists() and not force:
        try:
            data=np.load(path,allow_pickle=False)
            cached=str(data['signature'].item())
            if cached==signature and len(data['X'])>=cfg.nn.samples:
                return data['X'][:cfg.nn.samples],data['Y'][:cfg.nn.samples]
        except (ValueError,KeyError,OSError,EOFError):
            pass
    X=latin_hypercube(cfg.nn.samples,cfg,cfg.nn.seed);Y=[]
    for idx,row in enumerate(X,1):
        geometry=geometry_from_design(row,cfg)
        result=solver.sweep(geometry)
        Y.append(spectral_target(result, port_reference_impedance(cfg.port)))
        print(f'dataset {idx:4d}/{len(X)}  L={row[0]*1e3:7.3f} mm  W={row[1]*1e3:7.3f} mm')
    Y=np.asarray(Y,float);path.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(path,X=X,Y=Y,signature=np.array(signature))
    return X,Y
