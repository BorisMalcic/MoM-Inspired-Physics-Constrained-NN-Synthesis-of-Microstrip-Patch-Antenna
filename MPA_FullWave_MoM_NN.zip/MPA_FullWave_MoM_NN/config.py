"""Configuration for the Active/Robust full-wave spectral MoM + NN project.

The electromagnetic data used for training and validation is generated only by
spectral-domain Method of Moments (MoM).  No cavity model, closed-form resonant
length model, empirical geometry proxy, or port-current scaling factor is used.

Model scope:
- finite rectangular PEC patch printed on an infinite lossy grounded substrate;
- full-wave TE/TM spectral grounded-slab operator;
- entire-domain vector basis on the patch;
- idealized SMA/coax modal terminal projected on the patch plane;
- ensemble neural surrogate, active learning, and robust tolerance evaluation.
"""
from __future__ import annotations
from dataclasses import dataclass, field, replace
from typing import Tuple, Literal
import numpy as np

ISM_FREQS = np.array([2.400e9, 2.420e9, 2.44175e9, 2.462e9, 2.4835e9], dtype=float)


@dataclass
class MaterialConfig:
    eps_r: float = 4.4
    loss_tan: float = 0.020
    substrate_h_m: float = 1.53e-3
    copper_sigma_s_per_m: float = 5.8e7
    copper_thickness_m: float = 35e-6


@dataclass
class GeometryConfig:
    # Python convention: patch_length is resonant length L; patch_width is W.
    patch_length_m: float = 28.5e-3
    patch_width_m: float = 44.0e-3
    board_x_m: float = 60e-3
    board_y_m: float = 62e-3
    feed_x_m: float = 5.5e-3
    feed_y_m: float = 0.0
    terminal_gap_m: float = 0.50e-3
    terminal_span_y_m: float = 4.0e-3
    source_voltage_v: float = 1.0


@dataclass
class PortConfig:
    port_model: Literal["delta_gap", "sma_coax_50ohm"] = "sma_coax_50ohm"
    inner_conductor_radius_m: float = 0.35e-3
    shield_inner_radius_m: float = 1.20e-3
    coax_dielectric_eps_r: float = 2.18617639394
    reference_impedance_ohm: float = 50.0
    contact_radius_factor: float = 1.00
    radial_order: int = 10
    angular_order: int = 48


@dataclass
class BasisConfig:
    # x-current modes: mx_x * ny_x; y-current modes: mx_y * ny_y.
    mx_x: int = 2
    ny_x: int = 1
    mx_y: int = 1
    ny_y: int = 1


@dataclass
class SpectralConfig:
    radial_order_per_segment: int = 16
    angular_samples: int = 32
    k_rho_max_factor: float = 35.0
    branch_guard_fraction: float = 0.015
    matrix_regularization_relative: float = 1e-11
    condition_warning: float = 1e10


@dataclass
class SweepConfig:
    synthesis_frequencies_hz: np.ndarray = field(default_factory=lambda: ISM_FREQS.copy())
    display_frequencies_hz: np.ndarray = field(default_factory=lambda: np.linspace(2.30e9, 2.60e9, 31))


@dataclass
class BoundsConfig:
    patch_length_m: Tuple[float, float] = (25e-3, 33e-3)
    patch_width_m: Tuple[float, float] = (34e-3, 56e-3)
    feed_x_fraction: Tuple[float, float] = (0.03, 0.45)
    feed_y_m: Tuple[float, float] = (-0.8e-3, 0.8e-3)
    terminal_span_y_m: Tuple[float, float] = (2.5e-3, 7.0e-3)


@dataclass
class NNConfig:
    samples: int = 8
    seed: int = 7
    hidden: int = 64
    depth: int = 3
    epochs: int = 120
    batch_size: int = 4
    learning_rate: float = 5e-4
    patience: int = 45
    ensemble_size: int = 3
    candidate_pool: int = 1200
    fullwave_candidates: int = 4
    local_refine_evaluations: int = 6


@dataclass
class ActiveLearningConfig:
    enabled: bool = True
    iterations: int = 1
    acquisitions_per_iteration: int = 1
    candidate_pool: int = 600
    uncertainty_weight: float = 0.22
    diversity_weight: float = 0.07
    min_normalized_distance: float = 0.040
    retrain_epochs_factor: float = 0.65


@dataclass
class ToleranceConfig:
    enabled: bool = True
    samples: int = 3
    seed: int = 2026
    # Uniform tolerances.  Each perturbation is clipped to +/- tolerance.
    patch_length_tol_m: float = 0.10e-3
    patch_width_tol_m: float = 0.10e-3
    feed_x_tol_m: float = 0.05e-3
    feed_y_tol_m: float = 0.05e-3
    terminal_span_tol_m: float = 0.05e-3
    eps_r_tol: float = 0.15
    substrate_h_tol_m: float = 0.03e-3
    # Robust score = mean + std_weight*std + worst_weight*worst.
    std_weight: float = 1.5
    worst_weight: float = 0.25
    robust_candidates: int = 2




@dataclass
class CrossValidationConfig:
    enabled: bool = True
    folds: int = 3
    repeats: int = 1
    seed: int = 123
    # To keep CV affordable, each fold may train for fewer epochs than the final model.
    epochs_factor: float = 0.65


@dataclass
class GeneticAlgorithmConfig:
    enabled: bool = True
    population: int = 6
    generations: int = 2
    elite_fraction: float = 0.20
    mutation_sigma_fraction: float = 0.075
    crossover_probability: float = 0.85
    seed: int = 404


@dataclass
class BenchmarkConfig:
    enabled: bool = True
    # Number of full-wave evaluations for direct random-search baseline.
    random_search_evaluations: int = 3
    # Number of independently repeated optimizer runs for statistical comparison.
    repeats: int = 1
    seed: int = 909



@dataclass
class SurrogateComparisonConfig:
    enabled: bool = True
    folds: int = 3
    repeats: int = 1
    seed: int = 818
    epochs_factor: float = 0.45
    mlp_ensemble_size: int = 2


@dataclass
class InverseModelConfig:
    enabled: bool = True
    hidden: int = 64
    depth: int = 3
    epochs: int = 120
    batch_size: int = 4
    learning_rate: float = 5e-4
    patience: int = 45
    ensemble_size: int = 3
    seed: int = 1777


@dataclass
class InverseComparisonConfig:
    enabled: bool = True
    inverse_candidates: int = 4
    refine_evaluations: int = 5
    direct_optimization_evaluations: int = 5
    stochastic_sigma_fraction: float = 0.055
    seed: int = 2288

@dataclass
class ProjectConfig:
    material: MaterialConfig = field(default_factory=MaterialConfig)
    geometry: GeometryConfig = field(default_factory=GeometryConfig)
    port: PortConfig = field(default_factory=PortConfig)
    basis: BasisConfig = field(default_factory=BasisConfig)
    spectral: SpectralConfig = field(default_factory=SpectralConfig)
    sweep: SweepConfig = field(default_factory=SweepConfig)
    bounds: BoundsConfig = field(default_factory=BoundsConfig)
    nn: NNConfig = field(default_factory=NNConfig)
    active: ActiveLearningConfig = field(default_factory=ActiveLearningConfig)
    tolerance: ToleranceConfig = field(default_factory=ToleranceConfig)
    cross_validation: CrossValidationConfig = field(default_factory=CrossValidationConfig)
    ga: GeneticAlgorithmConfig = field(default_factory=GeneticAlgorithmConfig)
    benchmark: BenchmarkConfig = field(default_factory=BenchmarkConfig)
    surrogate_comparison: SurrogateComparisonConfig = field(default_factory=SurrogateComparisonConfig)
    inverse_model: InverseModelConfig = field(default_factory=InverseModelConfig)
    inverse_comparison: InverseComparisonConfig = field(default_factory=InverseComparisonConfig)
    profile_name: str = "quick"


def profile_config(name: str) -> ProjectConfig:
    name = name.lower().strip()
    cfg = ProjectConfig(profile_name=name)
    if name == "quick":
        return cfg
    if name == "standard":
        cfg.basis = BasisConfig(mx_x=3, ny_x=2, mx_y=2, ny_y=3)
        cfg.spectral = SpectralConfig(
            radial_order_per_segment=30,
            angular_samples=64,
            k_rho_max_factor=50.0,
            branch_guard_fraction=0.010,
            matrix_regularization_relative=1e-12,
            condition_warning=1e11,
        )
        cfg.nn = NNConfig(
            samples=40, seed=7, hidden=128, depth=3, epochs=280,
            batch_size=8, learning_rate=4e-4, patience=70,
            ensemble_size=4, candidate_pool=12000,
            fullwave_candidates=10, local_refine_evaluations=30,
        )
        cfg.active = ActiveLearningConfig(
            enabled=True, iterations=3, acquisitions_per_iteration=4,
            candidate_pool=6000, uncertainty_weight=0.20,
            diversity_weight=0.06, min_normalized_distance=0.035,
            retrain_epochs_factor=0.70,
        )
        cfg.tolerance = ToleranceConfig(
            enabled=True, samples=16, robust_candidates=5,
            patch_length_tol_m=0.10e-3, patch_width_tol_m=0.10e-3,
            feed_x_tol_m=0.05e-3, feed_y_tol_m=0.05e-3,
            terminal_span_tol_m=0.05e-3, eps_r_tol=0.15,
            substrate_h_tol_m=0.03e-3, std_weight=1.8, worst_weight=0.30,
        )
        cfg.cross_validation = CrossValidationConfig(enabled=True, folds=5, repeats=1, seed=123, epochs_factor=0.65)
        cfg.ga = GeneticAlgorithmConfig(enabled=True, population=26, generations=10, elite_fraction=0.20,
                                        mutation_sigma_fraction=0.060, crossover_probability=0.88, seed=404)
        cfg.benchmark = BenchmarkConfig(enabled=True, random_search_evaluations=18, repeats=3, seed=909)
        cfg.surrogate_comparison = SurrogateComparisonConfig(enabled=True, folds=5, repeats=1, seed=818, epochs_factor=0.45, mlp_ensemble_size=2)
        cfg.inverse_model = InverseModelConfig(enabled=True, hidden=128, depth=3, epochs=220, batch_size=8, learning_rate=4e-4, patience=65, ensemble_size=4, seed=1777)
        cfg.inverse_comparison = InverseComparisonConfig(enabled=True, inverse_candidates=5, refine_evaluations=12, direct_optimization_evaluations=12, stochastic_sigma_fraction=0.050, seed=2288)
        cfg.sweep = SweepConfig(
            synthesis_frequencies_hz=np.array(
                [2.400e9, 2.412e9, 2.425e9, 2.437e9, 2.44175e9,
                 2.450e9, 2.462e9, 2.475e9, 2.4835e9], dtype=float
            ),
            display_frequencies_hz=np.linspace(2.25e9, 2.65e9, 61),
        )
        return cfg
    if name == "publication":
        cfg.basis = BasisConfig(mx_x=4, ny_x=3, mx_y=3, ny_y=4)
        cfg.spectral = SpectralConfig(
            radial_order_per_segment=52,
            angular_samples=96,
            k_rho_max_factor=70.0,
            branch_guard_fraction=0.0075,
            matrix_regularization_relative=1e-13,
            condition_warning=1e12,
        )
        cfg.nn = NNConfig(
            samples=100, seed=7, hidden=192, depth=4, epochs=420,
            batch_size=12, learning_rate=3e-4, patience=100,
            ensemble_size=5, candidate_pool=30000,
            fullwave_candidates=15, local_refine_evaluations=50,
        )
        cfg.active = ActiveLearningConfig(
            enabled=True, iterations=4, acquisitions_per_iteration=6,
            candidate_pool=15000, uncertainty_weight=0.18,
            diversity_weight=0.05, min_normalized_distance=0.030,
            retrain_epochs_factor=0.70,
        )
        cfg.tolerance = ToleranceConfig(
            enabled=True, samples=32, robust_candidates=8,
            patch_length_tol_m=0.10e-3, patch_width_tol_m=0.10e-3,
            feed_x_tol_m=0.05e-3, feed_y_tol_m=0.05e-3,
            terminal_span_tol_m=0.05e-3, eps_r_tol=0.15,
            substrate_h_tol_m=0.03e-3, std_weight=2.0, worst_weight=0.35,
        )
        cfg.cross_validation = CrossValidationConfig(enabled=True, folds=5, repeats=2, seed=123, epochs_factor=0.75)
        cfg.ga = GeneticAlgorithmConfig(enabled=True, population=40, generations=16, elite_fraction=0.18,
                                        mutation_sigma_fraction=0.045, crossover_probability=0.90, seed=404)
        cfg.benchmark = BenchmarkConfig(enabled=True, random_search_evaluations=30, repeats=3, seed=909)
        cfg.surrogate_comparison = SurrogateComparisonConfig(enabled=True, folds=5, repeats=2, seed=818, epochs_factor=0.50, mlp_ensemble_size=3)
        cfg.inverse_model = InverseModelConfig(enabled=True, hidden=192, depth=4, epochs=340, batch_size=12, learning_rate=3e-4, patience=90, ensemble_size=5, seed=1777)
        cfg.inverse_comparison = InverseComparisonConfig(enabled=True, inverse_candidates=6, refine_evaluations=20, direct_optimization_evaluations=20, stochastic_sigma_fraction=0.040, seed=2288)
        cfg.sweep = SweepConfig(
            synthesis_frequencies_hz=np.linspace(2.400e9, 2.4835e9, 17),
            display_frequencies_hz=np.linspace(2.20e9, 2.70e9, 101),
        )
        return cfg
    raise ValueError(f"Unknown profile: {name!r}. Use quick, standard, or publication.")


def smoke_config() -> ProjectConfig:
    cfg = profile_config("quick")
    cfg.basis = BasisConfig(mx_x=1, ny_x=1, mx_y=1, ny_y=1)
    cfg.spectral = SpectralConfig(
        radial_order_per_segment=10,
        angular_samples=20,
        k_rho_max_factor=20.0,
        branch_guard_fraction=0.02,
        matrix_regularization_relative=1e-10,
        condition_warning=1e12,
    )
    cfg.sweep = SweepConfig(
        synthesis_frequencies_hz=np.array([2.44175e9]),
        display_frequencies_hz=np.array([2.44175e9]),
    )
    cfg.nn = replace(cfg.nn, samples=4, epochs=20, ensemble_size=1,
                     candidate_pool=40, fullwave_candidates=2,
                     local_refine_evaluations=2)
    cfg.active = ActiveLearningConfig(enabled=True, iterations=1, acquisitions_per_iteration=1,
                                      candidate_pool=30, uncertainty_weight=0.1,
                                      diversity_weight=0.0,
                                      min_normalized_distance=0.02,
                                      retrain_epochs_factor=0.5)
    cfg.tolerance = ToleranceConfig(enabled=True, samples=3, robust_candidates=1)
    cfg.cross_validation = CrossValidationConfig(enabled=True, folds=2, repeats=1, seed=123, epochs_factor=0.50)
    cfg.ga = GeneticAlgorithmConfig(enabled=True, population=6, generations=2, elite_fraction=0.33,
                                    mutation_sigma_fraction=0.10, crossover_probability=0.80, seed=404)
    cfg.benchmark = BenchmarkConfig(enabled=True, random_search_evaluations=3, repeats=1, seed=909)
    cfg.surrogate_comparison = SurrogateComparisonConfig(enabled=True, folds=2, repeats=1, seed=818, epochs_factor=0.40, mlp_ensemble_size=1)
    cfg.inverse_model = InverseModelConfig(enabled=True, hidden=32, depth=2, epochs=30, batch_size=2, learning_rate=8e-4, patience=12, ensemble_size=1, seed=1777)
    cfg.inverse_comparison = InverseComparisonConfig(enabled=True, inverse_candidates=2, refine_evaluations=2, direct_optimization_evaluations=2, stochastic_sigma_fraction=0.080, seed=2288)
    cfg.profile_name = "smoke"
    return cfg
