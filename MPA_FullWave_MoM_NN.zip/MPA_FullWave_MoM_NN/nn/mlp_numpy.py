from __future__ import annotations
import numpy as np


class Standardizer:
    def fit(self,x):
        self.mean=np.mean(x,axis=0);self.std=np.std(x,axis=0);self.std=np.where(self.std<1e-12,1.0,self.std);return self
    def transform(self,x): return (np.asarray(x)-self.mean)/self.std
    def inverse(self,x): return np.asarray(x)*self.std+self.mean


class MLP:
    def __init__(self,input_dim,output_dim,hidden=64,depth=3,seed=7):
        rng=np.random.default_rng(seed);dims=[input_dim]+[hidden]*depth+[output_dim]
        self.W=[];self.b=[]
        for a,b in zip(dims[:-1],dims[1:]):
            self.W.append(rng.normal(0,np.sqrt(2/a),(a,b)));self.b.append(np.zeros(b))
    def _forward(self,x):
        A=[x];Z=[]
        for i,(w,b) in enumerate(zip(self.W,self.b)):
            z=A[-1]@w+b;Z.append(z);A.append(np.tanh(z) if i<len(self.W)-1 else z)
        return A,Z
    def predict(self,x): return self._forward(np.asarray(x,float))[0][-1]
    def fit(self,x,y,epochs=200,batch_size=8,lr=5e-4,patience=50,seed=7,validation_data=None):
        rng=np.random.default_rng(seed);n=len(x)
        if validation_data is None:
            idx=np.arange(n);split=max(1,int(.8*n));rng.shuffle(idx);tr=idx[:split];va=idx[split:] if split<n else idx[:1]
            x_train=x; y_train=y; x_val=x; y_val=y
        else:
            tr=np.arange(n); va=None
            x_train=x; y_train=y; x_val,y_val=validation_data
        mw=[np.zeros_like(w) for w in self.W];vw=[np.zeros_like(w) for w in self.W];mb=[np.zeros_like(b) for b in self.b];vb=[np.zeros_like(b) for b in self.b]
        beta1=.9;beta2=.999;eps=1e-8;step=0;best=np.inf;best_state=None;wait=0;history=[]
        for epoch in range(epochs):
            order=rng.permutation(tr)
            for start in range(0,len(order),batch_size):
                batch=order[start:start+batch_size];A,Z=self._forward(x_train[batch]);delta=2*(A[-1]-y_train[batch])/max(1,len(batch));gw=[];gb=[]
                for layer in range(len(self.W)-1,-1,-1):
                    gw.append(A[layer].T@delta);gb.append(np.sum(delta,axis=0))
                    if layer>0:delta=(delta@self.W[layer].T)*(1-np.tanh(Z[layer-1])**2)
                gw=gw[::-1];gb=gb[::-1];step+=1
                for i in range(len(self.W)):
                    mw[i]=beta1*mw[i]+(1-beta1)*gw[i];vw[i]=beta2*vw[i]+(1-beta2)*gw[i]**2;mb[i]=beta1*mb[i]+(1-beta1)*gb[i];vb[i]=beta2*vb[i]+(1-beta2)*gb[i]**2
                    self.W[i]-=lr*(mw[i]/(1-beta1**step))/(np.sqrt(vw[i]/(1-beta2**step))+eps)
                    self.b[i]-=lr*(mb[i]/(1-beta1**step))/(np.sqrt(vb[i]/(1-beta2**step))+eps)
            train=float(np.mean((self.predict(x_train[tr])-y_train[tr])**2))
            if validation_data is None:
                val=float(np.mean((self.predict(x_val[va])-y_val[va])**2))
            else:
                val=float(np.mean((self.predict(x_val)-y_val)**2))
            history.append((epoch,train,val))
            if val<best-1e-9:
                best=val;best_state=([w.copy() for w in self.W],[b.copy() for b in self.b]);wait=0
            else:wait+=1
            if wait>=patience:break
        if best_state is not None:self.W,self.b=best_state
        return np.asarray(history,float)
