from __future__ import annotations
import numpy as np
from .mlp_numpy import MLP,Standardizer


class EnsembleSurrogate:
    def __init__(self,cfg):
        self.cfg=cfg;self.models=[];self.histories=[]
    def fit(self,X,Y,validation_data=None):
        self.models=[];self.histories=[]
        self.xs=Standardizer().fit(X);self.ys=Standardizer().fit(Y);x=self.xs.transform(X);y=self.ys.transform(Y)
        val_scaled = None
        if validation_data is not None:
            Xv, Yv = validation_data
            val_scaled = (self.xs.transform(Xv), self.ys.transform(Yv))
        for i in range(self.cfg.ensemble_size):
            model=MLP(x.shape[1],y.shape[1],self.cfg.hidden,self.cfg.depth,self.cfg.seed+101*i)
            hist=model.fit(x,y,self.cfg.epochs,self.cfg.batch_size,self.cfg.learning_rate,self.cfg.patience,self.cfg.seed+37*i,validation_data=val_scaled)
            self.models.append(model);self.histories.append(hist)
        return self
    def predict_members(self,X):
        x=self.xs.transform(X);return np.stack([self.ys.inverse(m.predict(x)) for m in self.models],axis=0)
    def predict(self,X):
        p=self.predict_members(X);return np.mean(p,axis=0),np.std(p,axis=0)
