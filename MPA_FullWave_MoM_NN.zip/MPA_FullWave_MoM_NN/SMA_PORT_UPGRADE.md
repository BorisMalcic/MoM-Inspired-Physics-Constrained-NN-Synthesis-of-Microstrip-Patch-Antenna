# SMA/coax 50-ohm port model

This version adds an explicit SMA/coax port configuration to the full-wave spectral-domain MoM + NN synthesis project.



The new `PortConfig` in `config.py` contains:

port\_model = "sma\_coax\_50ohm"
inner\_conductor\_radius\_m = 0.35e-3
shield\_inner\_radius\_m = 1.20e-3
coax\_dielectric\_eps\_r = 2.18617639394
reference\_impedance\_ohm = 50.0



The coax characteristic impedance is computed from the TEM formula Z0 = 60/sqrt(eps\_r) \* ln(b/a)



where `a` is the inner conductor radius and `b` is the shield inner radius.  For `a = 0.35 mm` and `b = 1.20 mm`, the dielectric constant required for 50 ohm is approximately `2.18617639394`.



The spectral-domain MoM solver remains a planar full-wave solver for a finite patch on an infinite grounded lossy dielectric slab.  It does not mesh the full 3-D SMA connector body.  Instead, the SMA/coax port is represented by an idealized coax modal terminal projected onto the patch basis through a finite contact/frill region around the feed point.

The antenna impedance is still calculated from the solved MoM current coefficients using

Zin = Vport / Iport

No `port\\\_current\\\_scale` or hidden impedance calibration is used.

## 

## Notes:

`S11` and the Smith chart are now referenced to the computed coax characteristic impedance.  With the default parameters this is essentially Zo=50 ohm:



This is a planar spectral-domain MoM with an ideal SMA/coax modal terminal.  It is not a full 3-D meshed SMA connector model.

