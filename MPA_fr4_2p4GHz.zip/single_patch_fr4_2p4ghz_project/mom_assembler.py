import math
from typing import Dict, List, Tuple

import numpy as np

from basis import RooftopBasis
from config import SolverConfig
from greens import C0, ETA0, MU0, LayeredGreenDyadic

POL_TO_VEC = {
    'x': np.array([1.0, 0.0], dtype=np.float64),
    'y': np.array([0.0, 1.0], dtype=np.float64),
}


class PatchMoMAssembler:
    def __init__(self, green: LayeredGreenDyadic, solver_cfg: SolverConfig):
        self.green = green
        self.solver_cfg = solver_cfg

    def self_term_regularization(self, b: RooftopBasis, freq_hz: float) -> complex:
        k0 = 2.0 * math.pi * freq_hz / C0
        aeq = math.sqrt(max(b.support_area, 1e-18) / math.pi)
        rrad = ETA0 * k0 * aeq * 0.03
        xself = ETA0 * k0 * aeq * 0.18
        return complex(rrad + self.solver_cfg.regularization_ohm, xself)

    def cell_interaction_integral(self, bm: RooftopBasis, bn: RooftopBasis, freq_hz: float) -> complex:
        em = POL_TO_VEC[bm.polarization]
        en = POL_TO_VEC[bn.polarization]
        G = self.green.dyadic(bm.center, bn.center, freq_hz)
        approx = em @ G @ en
        z_mn = 1j * 2.0 * math.pi * freq_hz * MU0 * approx * bm.support_area * bn.support_area
        same_center_pol = bm.center == bn.center and bm.polarization == bn.polarization
        if bm is bn or same_center_pol:
            z_mn += self.self_term_regularization(bm, freq_hz)
        return z_mn

    def assemble_z_matrix(self, basis: List[RooftopBasis], freq_hz: float) -> np.ndarray:
        n = len(basis)
        Z = np.zeros((n, n), dtype=np.complex128)
        for m in range(n):
            for n_idx in range(n):
                Z[m, n_idx] = self.cell_interaction_integral(basis[m], basis[n_idx], freq_hz)
        return Z

    @staticmethod
    def solve_currents(Z: np.ndarray, V: np.ndarray) -> np.ndarray:
        return np.linalg.solve(Z, V)

    def estimate_input_impedance(self, V: np.ndarray, I: np.ndarray) -> complex:
        Iin = np.sum(I[np.abs(V) > 0])
        Vin = np.sum(V[np.abs(V) > 0])
        return Vin / (Iin + 1e-18)

    def far_field_3d(self, basis: List[RooftopBasis], I: np.ndarray, freq_hz: float,
                     theta_deg: np.ndarray, phi_deg: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        k0 = 2.0 * math.pi * freq_hz / C0
        th = np.radians(theta_deg)
        ph = np.radians(phi_deg)
        E_th = np.zeros((len(theta_deg), len(phi_deg)), dtype=np.complex128)
        E_ph = np.zeros_like(E_th)

        for it, t in enumerate(th):
            st, ct = np.sin(t), np.cos(t)
            for ip, p in enumerate(ph):
                cp, sp = np.cos(p), np.sin(p)
                eth = 0.0 + 0.0j
                eph = 0.0 + 0.0j
                for coeff, bf in zip(I, basis):
                    x, y = bf.center
                    phase = np.exp(1j * k0 * (x * st * cp + y * st * sp))
                    scale = coeff * bf.support_area
                    if bf.polarization == 'x':
                        ex = scale * phase
                        ey = 0.0
                    else:
                        ex = 0.0
                        ey = scale * phase
                    eth += (ex * cp + ey * sp) * ct
                    eph += (-ex * sp + ey * cp)
                E_th[it, ip] = eth
                E_ph[it, ip] = eph
        E_tot = np.sqrt(np.abs(E_th) ** 2 + np.abs(E_ph) ** 2)
        return E_th, E_ph, E_tot

    def directivity_from_field(self, E_tot: np.ndarray, theta_deg: np.ndarray, phi_deg: np.ndarray) -> np.ndarray:
        th = np.radians(theta_deg)
        ph = np.radians(phi_deg)
        U = np.abs(E_tot) ** 2
        dth = abs(th[1] - th[0]) if len(th) > 1 else 1.0
        dph = abs(ph[1] - ph[0]) if len(ph) > 1 else 1.0
        power = np.sum(U * np.sin(th)[:, None]) * dth * dph + 1e-18
        D = 4.0 * math.pi * U / power
        return D

    @staticmethod
    def pattern_cut_metrics(theta_deg: np.ndarray, patt_db: np.ndarray) -> Dict[str, float]:
        peak = int(np.argmax(patt_db))
        scan_deg = float(theta_deg[peak])
        target = patt_db[peak] - 3.0
        left = peak
        while left > 0 and patt_db[left] > target:
            left -= 1
        right = peak
        while right < len(patt_db) - 1 and patt_db[right] > target:
            right += 1
        hpbw = float(theta_deg[right] - theta_deg[left])
        mask = np.ones_like(patt_db, dtype=bool)
        mask[max(0, peak - 5):min(len(patt_db), peak + 6)] = False
        sll = float(np.max(patt_db[mask]) - np.max(patt_db)) if np.any(mask) else -60.0
        return {'scan_deg': scan_deg, 'hpbw_deg': hpbw, 'sll_db': sll}
