import math
from typing import Tuple

import numpy as np

from config import SolverConfig, SubstrateConfig, C0

MU0 = 4.0e-7 * math.pi
EPS0 = 1.0 / (MU0 * C0 * C0)
ETA0 = math.sqrt(MU0 / EPS0)


class LayeredGreenDyadic:
    """
    Runnable proxy Green dyadic.
    This is not a rigorous spectral-domain grounded-slab kernel.
    """

    def __init__(self, substrate: SubstrateConfig, solver_cfg: SolverConfig):
        self.substrate = substrate
        self.solver_cfg = solver_cfg

    def dyadic_spatial_proxy(self, r_obs: Tuple[float, float], r_src: Tuple[float, float], freq_hz: float) -> np.ndarray:
        x1, y1 = r_obs
        x2, y2 = r_src
        dx = x1 - x2
        dy = y1 - y2
        rho = math.sqrt(dx * dx + dy * dy)

        k0 = 2.0 * math.pi * freq_hz / C0
        # avoid over-singular off-diagonal blowup in overlapping layouts
        rho_eff = max(rho, 0.35e-3)
        phase = np.exp(-1j * k0 * rho_eff)
        amp = phase / (4.0 * math.pi * rho_eff)

        eeff = max(self.substrate.eps_eff_proxy, 1.0)
        slab_factor = 1.0 / math.sqrt(eeff)
        tangential_decay = np.exp(-0.30 * k0 * self.substrate.thickness_m)
        loss_factor = np.exp(-0.5 * self.substrate.loss_tan * k0 * self.substrate.thickness_m)
        base = amp * slab_factor * tangential_decay * loss_factor

        ratio_x = dx * dx / (rho_eff * rho_eff)
        ratio_y = dy * dy / (rho_eff * rho_eff)
        cross = dx * dy / (rho_eff * rho_eff)

        gxx = base * (1.0 + 0.18 * ratio_x)
        gyy = base * (1.0 + 0.18 * ratio_y)
        gxy = base * (0.08 * cross)
        gyx = gxy
        return np.array([[gxx, gxy], [gyx, gyy]], dtype=np.complex128)

    def dyadic(self, r_obs: Tuple[float, float], r_src: Tuple[float, float], freq_hz: float) -> np.ndarray:
        if self.solver_cfg.use_placeholder_kernel:
            return self.dyadic_spatial_proxy(r_obs, r_src, freq_hz)
        raise NotImplementedError('Exact layered spectral Green dyadic is not implemented in this runnable proxy project.')
