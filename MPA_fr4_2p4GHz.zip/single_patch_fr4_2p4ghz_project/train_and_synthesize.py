import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  

from config import CoaxFeedConfig, FrequencySweepConfig, NNSynthesisConfig, SolverConfig, SubstrateConfig
from dataset_and_metrics import (
    BASE_PATCH_X, BASE_PATCH_Y, BASE_SUB_X, BASE_SUB_Y, BASE_FEED_X, BASE_FEED_Y,
    build_dataset, local_refine, make_frequency_grid, x_to_geom_and_substrate, clip_design_vector, objective, extract_metrics
)
from nn_numpy import MLPRegressorNP, StandardScalerNP
from solver import PatchArrayMoMSolver


def save_return_loss(result):
    fig, ax = plt.subplots(figsize=(8, 4.6))
    ax.plot(result.freq_hz / 1e9, result.s11_db, lw=2)
    ax.axvline(2.4, color='r', ls='--', lw=1, label='target 2.4 GHz')
    ax.axhline(-14.0, color='k', ls=':', lw=1, label='-14 dB target')
    ax.set_xlabel('Frequency [GHz]')
    ax.set_ylabel('Return Loss S11 [dB]')
    ax.set_title('Return Loss')
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig('return_loss.png', dpi=180, bbox_inches='tight')


def save_vswr(result):
    fig, ax = plt.subplots(figsize=(8, 4.6))
    ax.plot(result.freq_hz / 1e9, result.vswr, lw=2)
    ax.axvline(2.4, color='r', ls='--', lw=1, label='target 2.4 GHz')
    ax.axhline(1.45, color='k', ls=':', lw=1, label='VSWR target 1.45')
    ax.set_xlabel('Frequency [GHz]')
    ax.set_ylabel('VSWR')
    ax.set_title('Voltage Standing Wave Ratio')
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig('vswr.png', dpi=180, bbox_inches='tight')


def save_directivity(result):
    theta = result.theta_grid_deg
    phi0 = result.directivity_grid_dbi[:, 0]
    phi90 = result.directivity_grid_dbi[:, int(np.argmin(np.abs(result.phi_grid_deg - 90.0)))]
    fig, ax = plt.subplots(figsize=(8, 4.6))
    ax.plot(theta, phi0, label='phi=0 deg')
    ax.plot(theta, phi90, label='phi=90 deg')
    ax.axhline(6.5, color='k', ls=':', lw=1, label='6.5 dBi target')
    ax.set_xlabel('Theta [deg]')
    ax.set_ylabel('Directivity [dBi]')
    ax.set_title('Directivity / Gain Proxy')
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig('directivity.png', dpi=180, bbox_inches='tight')


def save_radiation_pattern(result):
    fig, ax = plt.subplots(figsize=(8, 4.6))
    ax.plot(result.theta_deg, result.total_pattern_db, lw=2)
    ax.set_xlabel('Theta [deg]')
    ax.set_ylabel('Normalized Pattern [dB]')
    ax.set_title('Radiation Pattern (Total, proxy)')
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig('radiation_pattern.png', dpi=180, bbox_inches='tight')


def save_e_h_patterns(result):
    fig, ax = plt.subplots(figsize=(8, 4.6))
    ax.plot(result.theta_deg, result.eplane_db, lw=2, label='E-plane')
    ax.plot(result.theta_deg, result.hplane_db, lw=2, label='H-plane')
    ax.set_xlabel('Theta [deg]')
    ax.set_ylabel('Normalized Pattern [dB]')
    ax.set_title('E-Field and H-Field Radiation Patterns')
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig('e_h_field_patterns.png', dpi=180, bbox_inches='tight')


def save_3d_polar(result):
    theta = np.radians(result.theta_grid_deg)
    phi = np.radians(result.phi_grid_deg)
    TH, PH = np.meshgrid(theta, phi, indexing='ij')
    R = result.pattern_3d_norm
    X = R * np.sin(TH) * np.cos(PH)
    Y = R * np.sin(TH) * np.sin(PH)
    Z = R * np.cos(TH)
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection='3d')
    ax.plot_surface(X, Y, Z, cmap='viridis', linewidth=0, antialiased=True, alpha=0.95)
    ax.set_title('3D Polar Plot (proxy upper hemisphere)')
    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    fig.tight_layout()
    fig.savefig('polar_3d.png', dpi=180, bbox_inches='tight')


def save_training_history(fwd, inv):
    fig, ax = plt.subplots(figsize=(8, 4.6))
    ax.plot(fwd.training_history['epoch'], fwd.training_history['train_loss'], label='forward train')
    ax.plot(fwd.training_history['epoch'], fwd.training_history['val_loss'], label='forward val')
    ax.plot(inv.training_history['epoch'], inv.training_history['train_loss'], label='inverse train')
    ax.plot(inv.training_history['epoch'], inv.training_history['val_loss'], label='inverse val')
    ax.set_xlabel('Epoch')
    ax.set_ylabel('Loss')
    ax.set_title('NN Training History')
    ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig('nn_training_history.png', dpi=180, bbox_inches='tight')


def save_summary(x_best, y_best, substrate, coax, result, mae):
    with open('synthesis_summary.txt', 'w', encoding='utf-8') as f:
        f.write('Aligned single FR4 patch 2.4 GHz MoM+NN synthesis summary\n')
        f.write('==================================================\n\n')
        f.write('This project is a MoM-style educational proxy aligned for comparison with the 3D FEM/FDTD frameworks.\n')
        f.write('It is not a rigorous full-wave HFSS/CST-equivalent solver.\n\n')
        f.write(f'Substrate eps_r = {substrate.eps_r}\n')
        f.write(f'Substrate thickness [mm] = {substrate.thickness_m * 1e3:.4f}\n')
        f.write(f'Substrate size [mm] = {result.substrate_size_x_m * 1e3:.3f} x {result.substrate_size_y_m * 1e3:.3f}\n')
        f.write(f'Coax inner radius [mm] = {coax.pin_radius_m * 1e3:.4f}\n')
        f.write(f'Coax outer radius [mm] = {coax.outer_radius_m * 1e3:.4f}\n')
        f.write(f'Pin height [mm] = {coax.pin_height_m * 1e3:.4f}\n\n')
        f.write('Best design vector [patch_x, patch_y, sub_x, sub_y, feed_x_offset, feed_y_offset] in mm:\n')
        f.write(', '.join(f'{v * 1e3:.4f}' for v in x_best) + '\n\n')
        f.write('EM metrics [f_res_GHz, S11@2.4_dB, VSWR@2.4, directivity_dBi, HPBW_deg, scan_deg]:\n')
        f.write(', '.join(f'{v:.4f}' for v in y_best) + '\n\n')
        f.write(f'score = {objective(y_best, np.array(NNSynthesisConfig().target_vector, dtype=np.float64)):.6f}\n')
        f.write('Forward MAE = ' + np.array2string(mae, precision=6) + '\n')
        f.write(f'S11_target_db = {result.s11_target_db:.6f}\n')
        f.write(f'VSWR_target = {result.vswr_target:.6f}\n')


def split_data(X, Y, seed=7):
    rng = np.random.default_rng(seed)
    idx = rng.permutation(len(X))
    X = X[idx]
    Y = Y[idx]
    n = len(X)
    n_train = max(12, int(round(0.60 * n)))
    n_val = max(4, int(round(0.20 * n)))
    n_test = n - n_train - n_val
    if n_test < 2:
        n_train -= (2 - n_test)
        n_test = n - n_train - n_val
    print(f'split sizes: train={n_train} val={n_val} test={n_test}')
    return X[:n_train], Y[:n_train], X[n_train:n_train+n_val], Y[n_train:n_train+n_val], X[n_train+n_val:], Y[n_train+n_val:]


def main():
    nn_cfg = NNSynthesisConfig()
    freq_cfg = FrequencySweepConfig()
    substrate = SubstrateConfig()
    coax = CoaxFeedConfig()
    solver_cfg = SolverConfig(use_placeholder_kernel=True)

    print('Building dataset for aligned single FR4 patch 2.4 GHz MoM+NN project...')
    X, Y = build_dataset(nn_cfg.n_samples, freq_cfg, substrate, coax, solver_cfg, seed=nn_cfg.seed)
    X_train, Y_train, X_val, Y_val, X_test, Y_test = split_data(X, Y, seed=nn_cfg.seed)

    xs = StandardScalerNP().fit(X_train)
    ys = StandardScalerNP().fit(Y_train)
    Xtr, Xva, Xte = xs.transform(X_train), xs.transform(X_val), xs.transform(X_test)
    Ytr, Yva = ys.transform(Y_train), ys.transform(Y_val)

    print('Training forward NN...')
    fwd = MLPRegressorNP(in_dim=6, out_dim=6, hidden=nn_cfg.hidden, depth=nn_cfg.depth, seed=nn_cfg.seed)
    fwd.fit(Xtr, Ytr, Xva, Yva, epochs=nn_cfg.epochs, batch_size=nn_cfg.batch_size, lr=nn_cfg.lr, patience=nn_cfg.patience)

    pred = ys.inverse_transform(fwd.predict(Xte))
    mae = np.mean(np.abs(pred - Y_test), axis=0)
    print('Forward MAE [f_res_GHz, S11@2.4_dB, VSWR@2.4, directivity_dBi, hpbw_deg, scan_deg]:')
    print(mae)

    print('Training inverse NN...')
    ts = StandardScalerNP().fit(Y_train)
    xs_inv = StandardScalerNP().fit(X_train)
    Ttr, Tva = ts.transform(Y_train), ts.transform(Y_val)
    Xdtr, Xdva = xs_inv.transform(X_train), xs_inv.transform(X_val)
    inv = MLPRegressorNP(in_dim=6, out_dim=6, hidden=nn_cfg.hidden, depth=nn_cfg.depth, seed=nn_cfg.seed + 1)
    inv.fit(Ttr, Xdtr, Tva, Xdva, epochs=nn_cfg.epochs, batch_size=nn_cfg.batch_size, lr=nn_cfg.lr, patience=nn_cfg.patience)

    target = np.array(nn_cfg.target_vector, dtype=np.float64).reshape(1, -1)
    x_seed = np.array([BASE_PATCH_X, BASE_PATCH_Y, BASE_SUB_X, BASE_SUB_Y, BASE_FEED_X, BASE_FEED_Y], dtype=np.float64)
    x_nn = xs_inv.inverse_transform(inv.predict(ts.transform(target)))[0]
    x0 = clip_design_vector(0.60 * clip_design_vector(x_nn) + 0.40 * x_seed)
    print('Inverse NN proposal blended with theoretical seed:')
    print(x0)

    solver = PatchArrayMoMSolver(substrate, coax, solver_cfg)
    freq = make_frequency_grid(freq_cfg)

    candidates = []
    # inverse blend
    candidates.append(x0)
    # theoretical seed
    candidates.append(clip_design_vector(x_seed))
    # best dataset sample
    idx_best = int(np.argmin([objective(y, target[0]) for y in Y]))
    candidates.append(clip_design_vector(X[idx_best]))

    scored = []
    for cand in candidates:
        geom_c, sub_c = x_to_geom_and_substrate(cand, substrate)
        res_c = solver.solve(geom_c, freq, substrate_override=sub_c)
        y_c = extract_metrics(res_c)
        scored.append((objective(y_c, target[0]), cand, y_c))
    scored.sort(key=lambda t: t[0])
    x_start = scored[0][1]

    x_best, y_best, s_best = local_refine(x_start, freq_cfg, substrate, coax, solver_cfg, target[0], n_steps=14, seed=1)
    print('After local refinement:')
    print('x_best =', x_best)
    print('y_best =', y_best)
    print('score  =', s_best)

    geom_best, sub_best = x_to_geom_and_substrate(x_best, substrate)
    result = solver.solve(geom_best, freq, substrate_override=sub_best)

    save_return_loss(result)
    save_vswr(result)
    save_directivity(result)
    save_radiation_pattern(result)
    save_e_h_patterns(result)
    save_3d_polar(result)
    save_training_history(fwd, inv)
    save_summary(x_best, y_best, sub_best, coax, result, mae)

    print('Saved output files:')
    for name in [
        'return_loss.png', 'vswr.png', 'directivity.png', 'radiation_pattern.png',
        'e_h_field_patterns.png', 'polar_3d.png', 'nn_training_history.png', 'synthesis_summary.txt',
    ]:
        print('  ', name)
    plt.close('all')


if __name__ == '__main__':
    main()
