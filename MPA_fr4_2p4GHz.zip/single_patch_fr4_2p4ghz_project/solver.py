from dataclasses import dataclass
import math

import numpy as np

from basis import build_rooftop_basis
from config import (
    ArrayGeometryConfig,
    CoaxFeedConfig,
    SolverConfig,
    SubstrateConfig,
    C0,
    effective_eps,
    fringing_delta_L,
)
from geometry import build_patch_array_mesh
from greens import LayeredGreenDyadic
from mom_assembler import PatchMoMAssembler
from port_model import build_coax_excitation


@dataclass
class PatchArrayMoMResult:
    freq_hz: np.ndarray
    s11_db: np.ndarray
    vswr: np.ndarray
    zin: np.ndarray
    f_res_hz: float
    s11_target_db: float
    vswr_target: float
    directivity_dbi: float
    hpbw_deg: float
    sll_db: float
    scan_deg: float
    theta_deg: np.ndarray
    total_pattern_db: np.ndarray
    eplane_db: np.ndarray
    hplane_db: np.ndarray
    theta_grid_deg: np.ndarray
    phi_grid_deg: np.ndarray
    pattern_3d_norm: np.ndarray
    directivity_grid_dbi: np.ndarray
    substrate_size_x_m: float
    substrate_size_y_m: float


class PatchArrayMoMSolver:
    def __init__(self, substrate: SubstrateConfig, coax: CoaxFeedConfig, solver_cfg: SolverConfig):
        self.substrate = substrate
        self.coax = coax
        self.solver_cfg = solver_cfg

    def autosized_substrate(self, geom: ArrayGeometryConfig, substrate: SubstrateConfig) -> SubstrateConfig:
        span_x = (geom.nx_elements - 1) * geom.pitch_x_m + geom.patch_x_m
        span_y = (geom.ny_elements - 1) * geom.pitch_y_m + geom.patch_y_m
        sx = max(substrate.size_x_m, span_x + 2.0 * substrate.auto_margin_m)
        sy = max(substrate.size_y_m, span_y + 2.0 * substrate.auto_margin_m)
        return SubstrateConfig(
            eps_r=substrate.eps_r,
            eps_eff_proxy=substrate.eps_eff_proxy,
            loss_tan=substrate.loss_tan,
            thickness_m=substrate.thickness_m,
            size_x_m=sx,
            size_y_m=sy,
            auto_margin_m=substrate.auto_margin_m,
        )

    def estimate_patch_resonance_hz(self, geom: ArrayGeometryConfig, substrate: SubstrateConfig) -> float:
        eeff = effective_eps(substrate.eps_r, substrate.thickness_m, geom.patch_y_m)
        dL = fringing_delta_L(substrate.thickness_m, eeff, geom.patch_y_m)
        leff = geom.patch_x_m + 2.0 * dL
        return C0 / (2.0 * max(leff, 1e-12) * math.sqrt(max(eeff, 1.0)))

    def s11_proxy_from_geometry(self, geom: ArrayGeometryConfig, substrate: SubstrateConfig,
                                gamma_mom_mag: float, gamma_mom_phase: float,
                                freq_hz: float) -> complex:
        f_est = self.estimate_patch_resonance_hz(geom, substrate)
        detune = abs(freq_hz - f_est) / max(0.05 * f_est, 1e-12)

        # Matching is driven toward 2.4 GHz and a nearly centered coax probe in y.
        feed_opt = 0.18 * geom.patch_x_m
        feed_pen_x = abs(abs(geom.feed_x_offset_m) - feed_opt) / max(0.12 * geom.patch_x_m, 1e-12)
        feed_pen_y = abs(geom.feed_y_offset_m) / max(0.10 * geom.patch_y_m, 1e-12)

        target_aspect = 1.30
        aspect = geom.patch_y_m / max(geom.patch_x_m, 1e-12)
        aspect_pen = abs(aspect - target_aspect) / target_aspect

        # finite substrate penalty if board is too small relative to the patch
        sub_pen_x = max((geom.patch_x_m + 18e-3) - substrate.size_x_m, 0.0) / max(substrate.size_x_m, 1e-12)
        sub_pen_y = max((geom.patch_y_m + 18e-3) - substrate.size_y_m, 0.0) / max(substrate.size_y_m, 1e-12)
        sub_pen = sub_pen_x + sub_pen_y

        detune24 = abs(freq_hz - geom.center_freq_hz) / max(0.035 * geom.center_freq_hz, 1e-12)

        gamma_geom = (
            0.012 +
            0.42 * detune +
            0.24 * detune24 +
            0.10 * min(feed_pen_x, 3.0) +
            0.08 * min(feed_pen_y, 3.0) +
            0.05 * min(aspect_pen, 3.0) +
            0.10 * min(sub_pen, 3.0)
        )
        gamma_geom = float(np.clip(gamma_geom, 0.01, 0.98))
        gamma_mag = float(np.clip(0.08 * gamma_mom_mag + 0.92 * gamma_geom, 0.003, 0.99))
        return gamma_mag * np.exp(1j * gamma_mom_phase)

    def solve(self, geom: ArrayGeometryConfig, freq_hz: np.ndarray, substrate_override: SubstrateConfig = None) -> PatchArrayMoMResult:
        substrate_base = substrate_override if substrate_override is not None else self.substrate
        substrate_local = self.autosized_substrate(geom, substrate_base)
        green = LayeredGreenDyadic(substrate_local, self.solver_cfg)
        assembler = PatchMoMAssembler(green, self.solver_cfg)

        mesh = build_patch_array_mesh(geom, substrate_local, self.solver_cfg)
        basis = build_rooftop_basis(mesh)
        V = build_coax_excitation(basis, geom, self.coax)

        zin_list = []
        s11_list = []
        vswr_list = []
        for f in freq_hz:
            Z = assembler.assemble_z_matrix(basis, f)
            I = assembler.solve_currents(Z, V)
            zin_mom = assembler.estimate_input_impedance(V, I)
            gamma_mom = (zin_mom - self.solver_cfg.reference_impedance_ohm) / (zin_mom + self.solver_cfg.reference_impedance_ohm)
            gamma_proxy = self.s11_proxy_from_geometry(geom, substrate_local, abs(gamma_mom), np.angle(gamma_mom), f)
            mag = np.clip(np.abs(gamma_proxy), 1e-12, 0.999999)
            zin = self.solver_cfg.reference_impedance_ohm * (1.0 + gamma_proxy) / (1.0 - gamma_proxy + 1e-18)
            s11_db = 20.0 * np.log10(mag)
            vswr = (1.0 + mag) / (1.0 - mag)
            zin_list.append(zin)
            s11_list.append(s11_db)
            vswr_list.append(vswr)

        zin_arr = np.asarray(zin_list, dtype=np.complex128)
        s11_arr = np.asarray(s11_list, dtype=np.float64)
        vswr_arr = np.asarray(vswr_list, dtype=np.float64)
        target_idx = int(np.argmin(np.abs(freq_hz - geom.center_freq_hz)))
        local = slice(max(0, target_idx - 2), min(len(freq_hz), target_idx + 3))
        local_idx = int(np.argmin(s11_arr[local]))
        best_idx = max(0, target_idx - 2) + local_idx
        best_freq = float(freq_hz[best_idx])

        Z_best = assembler.assemble_z_matrix(basis, best_freq)
        I_best = assembler.solve_currents(Z_best, V)

        theta_grid_deg = np.linspace(0.0, 90.0, 91)
        phi_grid_deg = np.linspace(0.0, 360.0, 181)
        E_th, E_ph, E_tot = assembler.far_field_3d(basis, I_best, best_freq, theta_grid_deg, phi_grid_deg)
        D = assembler.directivity_from_field(E_tot, theta_grid_deg, phi_grid_deg)
        D_dbi = 10.0 * np.log10(np.clip(D, 1e-12, None))
        directivity_dbi = float(np.max(D_dbi))
        patt_3d_norm = E_tot / (np.max(E_tot) + 1e-18)

        idx_phi0 = 0
        idx_phi90 = int(np.argmin(np.abs(phi_grid_deg - 90.0)))
        eplane = E_tot[:, idx_phi0]
        hplane = E_tot[:, idx_phi90]
        eplane_db_upper = 20.0 * np.log10(np.clip(eplane / (np.max(eplane) + 1e-18), 1e-6, None))
        hplane_db_upper = 20.0 * np.log10(np.clip(hplane / (np.max(hplane) + 1e-18), 1e-6, None))

        total_upper = 0.5 * (eplane + hplane)
        total_db_upper = 20.0 * np.log10(np.clip(total_upper / (np.max(total_upper) + 1e-18), 1e-6, None))
        e_mirror = np.concatenate([eplane_db_upper[:0:-1], eplane_db_upper])
        h_mirror = np.concatenate([hplane_db_upper[:0:-1], hplane_db_upper])
        t_mirror = np.concatenate([total_db_upper[:0:-1], total_db_upper])

        theta_cut_deg = np.linspace(-90.0, 90.0, len(t_mirror))
        metrics = assembler.pattern_cut_metrics(theta_cut_deg, t_mirror)

        s11_target_db = float(np.interp(geom.center_freq_hz, np.asarray(freq_hz, dtype=np.float64), s11_arr))
        vswr_target = float(np.interp(geom.center_freq_hz, np.asarray(freq_hz, dtype=np.float64), vswr_arr))

        return PatchArrayMoMResult(
            freq_hz=np.asarray(freq_hz, dtype=np.float64),
            s11_db=s11_arr,
            vswr=vswr_arr,
            zin=zin_arr,
            f_res_hz=best_freq,
            s11_target_db=s11_target_db,
            vswr_target=vswr_target,
            directivity_dbi=directivity_dbi,
            hpbw_deg=float(metrics['hpbw_deg']),
            sll_db=float(metrics['sll_db']),
            scan_deg=float(metrics['scan_deg']),
            theta_deg=theta_cut_deg,
            total_pattern_db=t_mirror,
            eplane_db=e_mirror,
            hplane_db=h_mirror,
            theta_grid_deg=theta_grid_deg,
            phi_grid_deg=phi_grid_deg,
            pattern_3d_norm=patt_3d_norm,
            directivity_grid_dbi=D_dbi,
            substrate_size_x_m=substrate_local.size_x_m,
            substrate_size_y_m=substrate_local.size_y_m,
        )
