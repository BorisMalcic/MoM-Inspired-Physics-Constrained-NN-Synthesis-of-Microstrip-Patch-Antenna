from typing import List, Tuple

import numpy as np

from basis import RooftopBasis
from config import ArrayGeometryConfig, CoaxFeedConfig


def feed_center_xy_for_patch(geom: ArrayGeometryConfig, patch_ix: int, patch_iy: int) -> Tuple[float, float]:
    total_span_x = (geom.nx_elements - 1) * geom.pitch_x_m
    total_span_y = (geom.ny_elements - 1) * geom.pitch_y_m
    x_center = patch_ix * geom.pitch_x_m - 0.5 * total_span_x + geom.feed_x_offset_m
    y_center = patch_iy * geom.pitch_y_m - 0.5 * total_span_y + geom.feed_y_offset_m
    return x_center, y_center


def build_coax_excitation(basis: List[RooftopBasis], geom: ArrayGeometryConfig, coax: CoaxFeedConfig) -> np.ndarray:
    """
    Coax-like local excitation proxy.
    For a single patch this behaves like one probe-fed patch with a localized current source.
    It is not a rigorous 3D coax model.
    """
    v = np.zeros(len(basis), dtype=np.complex128)

    sigma = max(
        coax.pin_radius_m,
        0.42 * geom.patch_x_m / geom.nx_per_patch,
        0.42 * geom.patch_y_m / geom.ny_per_patch,
    )

    selected = []
    for pix in range(geom.nx_elements):
        for piy in range(geom.ny_elements):
            x_feed, y_feed = feed_center_xy_for_patch(geom, pix, piy)
            local_weights = []
            nearest_idx = None
            nearest_d2 = float('inf')
            for idx, bf in enumerate(basis):
                if bf.cell.patch_ix != pix or bf.cell.patch_iy != piy:
                    continue
                dx = bf.cell.xc - x_feed
                dy = bf.cell.yc - y_feed
                d2 = dx * dx + dy * dy
                if d2 < nearest_d2:
                    nearest_d2 = d2
                    nearest_idx = idx
                local = np.exp(-0.5 * d2 / (sigma * sigma))
                pol_weight = 1.0 if bf.polarization == 'x' else 0.35
                local_weights.append((idx, local * pol_weight, d2))

            if not local_weights or nearest_idx is None:
                raise RuntimeError('Could not place local coax surrogate on patch basis set.')

            local_weights.sort(key=lambda t: t[2])
            top = local_weights[: min(4, len(local_weights))]
            s = sum(abs(w) for _, w, _ in top) + 1e-18
            for idx, w, _ in top:
                selected.append((idx, w / s))

    patch_count = max(geom.nx_elements * geom.ny_elements, 1)
    for idx, w in selected:
        v[idx] += (w / patch_count)

    if np.all(np.abs(v) < 1e-15):
        for idx, bf in enumerate(basis):
            if bf.polarization == 'x':
                v[idx] = 1.0
                break
    return v
