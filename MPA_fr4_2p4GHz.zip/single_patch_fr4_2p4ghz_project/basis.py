from dataclasses import dataclass
from typing import List, Tuple

from geometry import Cell, PatchArrayMesh


@dataclass
class RooftopBasis:
    cell: Cell
    polarization: str  # 'x' or 'y'

    @property
    def center(self) -> Tuple[float, float]:
        return self.cell.xc, self.cell.yc

    @property
    def support_area(self) -> float:
        return self.cell.area



def build_rooftop_basis(mesh: PatchArrayMesh) -> List[RooftopBasis]:
    basis: List[RooftopBasis] = []
    for cell in mesh.cells:
        basis.append(RooftopBasis(cell, 'x'))
        basis.append(RooftopBasis(cell, 'y'))
    return basis
