from typing import Tuple

import numpy as np

from config import (
    ArrayGeometryConfig,
    FrequencySweepConfig,
    SolverConfig,
    SubstrateConfig,
    CoaxFeedConfig,
    BASE_FREQ,
    BASE_PATCH_X,
    BASE_PATCH_Y,
)
from solver import PatchArrayMoMSolver

BASE_SUB_X = 60.0e-3
BASE_SUB_Y = 60.0e-3
BASE_FEED_X = 0.18 * BASE_PATCH_X
BASE_FEED_Y = 0.0


def make_frequency_grid(cfg: FrequencySweepConfig) -> np.ndarray:
    return np.linspace(cfg.f_start_hz, cfg.f_stop_hz, cfg.n_points)


# design vector = [patch_x, patch_y, sub_x, sub_y, feed_x_offset, feed_y_offset]
def sample_geometries(n_samples: int, seed: int = 7) -> np.ndarray:
    rng = np.random.default_rng(seed)
    x = np.zeros((n_samples, 6), dtype=np.float64)
    x[:, 0] = rng.uniform(0.90 * BASE_PATCH_X, 1.10 * BASE_PATCH_X, n_samples)
    x[:, 1] = rng.uniform(0.90 * BASE_PATCH_Y, 1.10 * BASE_PATCH_Y, n_samples)
    x[:, 2] = rng.uniform(50e-3, 75e-3, n_samples)
    x[:, 3] = rng.uniform(50e-3, 75e-3, n_samples)
    x[:, 4] = rng.uniform(0.10 * BASE_PATCH_X, 0.40 * BASE_PATCH_X, n_samples)
    x[:, 5] = rng.uniform(-0.05 * BASE_PATCH_Y, 0.05 * BASE_PATCH_Y, n_samples)
    return x


def clip_design_vector(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64).copy()
    x[0] = np.clip(x[0], 0.90 * BASE_PATCH_X, 1.10 * BASE_PATCH_X)
    x[1] = np.clip(x[1], 0.90 * BASE_PATCH_Y, 1.10 * BASE_PATCH_Y)
    x[2] = np.clip(x[2], max(x[0] + 20e-3, 50e-3), 80e-3)
    x[3] = np.clip(x[3], max(x[1] + 20e-3, 50e-3), 80e-3)
    x[4] = np.clip(x[4], 0.05 * x[0], 0.30 * x[0])
    x[5] = np.clip(x[5], -0.10 * x[1], 0.10 * x[1])
    return x


def x_to_geom_and_substrate(x: np.ndarray, template: SubstrateConfig = None):
    x = clip_design_vector(x)
    geom = ArrayGeometryConfig(
        nx_elements=1,
        ny_elements=1,
        center_freq_hz=BASE_FREQ,
        patch_x_m=float(x[0]),
        patch_y_m=float(x[1]),
        pitch_x_m=float(x[0]),
        pitch_y_m=float(x[1]),
        nx_per_patch=3,
        ny_per_patch=4,
        feed_x_offset_m=float(x[4]),
        feed_y_offset_m=float(x[5]),
    )
    base = template or SubstrateConfig()
    substrate = SubstrateConfig(
        eps_r=base.eps_r,
        eps_eff_proxy=base.eps_eff_proxy,
        loss_tan=base.loss_tan,
        thickness_m=base.thickness_m,
        size_x_m=float(x[2]),
        size_y_m=float(x[3]),
        auto_margin_m=base.auto_margin_m,
    )
    return geom, substrate


def extract_metrics(result) -> np.ndarray:
    return np.array([
        result.f_res_hz / 1e9,
        result.s11_target_db,
        result.vswr_target,
        result.directivity_dbi,
        result.hpbw_deg,
        result.scan_deg,
    ], dtype=np.float64)


def build_dataset(n_samples: int, freq_cfg: FrequencySweepConfig,
                  substrate: SubstrateConfig, coax: CoaxFeedConfig,
                  solver_cfg: SolverConfig, seed: int = 7) -> Tuple[np.ndarray, np.ndarray]:
    X = sample_geometries(n_samples, seed=seed)
    freq = make_frequency_grid(freq_cfg)
    solver = PatchArrayMoMSolver(substrate, coax, solver_cfg)
    Y = []
    for idx, x in enumerate(X):
        geom, sub_local = x_to_geom_and_substrate(x, substrate)
        res = solver.solve(geom, freq, substrate_override=sub_local)
        Y.append(extract_metrics(res))
        print(f'dataset sample {idx + 1}/{n_samples}')
    return X, np.asarray(Y, dtype=np.float64)


def objective(metrics: np.ndarray, target: np.ndarray) -> float:
    return float(
        ((metrics[0] - target[0]) / 0.04) ** 2 +
        (max(metrics[1] - target[1], 0.0) / 2.0) ** 2 +
        (max(metrics[2] - target[2], 0.0) / 0.20) ** 2 +
        (max(target[3] - metrics[3], 0.0) / 0.8) ** 2 +
        (max(target[4] - metrics[4], 0.0) / 12.0) ** 2 +
        ((metrics[5] - target[5]) / 6.0) ** 2
    )


def local_refine(initial_x: np.ndarray, freq_cfg: FrequencySweepConfig,
                 substrate: SubstrateConfig, coax: CoaxFeedConfig,
                 solver_cfg: SolverConfig, target: np.ndarray,
                 n_steps: int = 16, seed: int = 7):
    rng = np.random.default_rng(seed)
    freq = make_frequency_grid(freq_cfg)
    solver = PatchArrayMoMSolver(substrate, coax, solver_cfg)
    best_x = clip_design_vector(initial_x)
    best_geom, best_sub = x_to_geom_and_substrate(best_x, substrate)
    best_res = solver.solve(best_geom, freq, substrate_override=best_sub)
    best_y = extract_metrics(best_res)
    best_s = objective(best_y, target)
    step = np.array([0.5e-3, 0.7e-3, 1.5e-3, 1.5e-3, 0.25e-3, 0.20e-3], dtype=np.float64)

    for _ in range(n_steps):
        cand = clip_design_vector(best_x + rng.normal(0.0, 1.0, size=6) * step)
        geom, sub_local = x_to_geom_and_substrate(cand, substrate)
        res = solver.solve(geom, freq, substrate_override=sub_local)
        y = extract_metrics(res)
        s = objective(y, target)
        if s < best_s:
            best_x, best_y, best_s = cand, y, s
    return best_x, best_y, best_s
