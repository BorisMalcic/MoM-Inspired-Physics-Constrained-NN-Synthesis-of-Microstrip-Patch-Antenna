import numpy as np
import matplotlib.pyplot as plt

from config import CoaxFeedConfig, FrequencySweepConfig, NNSynthesisConfig, SolverConfig, SubstrateConfig
from dataset_and_metrics import (
    BASE_FEED_X, BASE_FEED_Y, BASE_PATCH_X, BASE_PATCH_Y, BASE_SUB_X, BASE_SUB_Y,
    clip_design_vector, local_refine, make_frequency_grid, x_to_geom_and_substrate, objective, extract_metrics
)
from solver import PatchArrayMoMSolver
from train_and_synthesize import (
    save_return_loss, save_vswr, save_directivity, save_radiation_pattern, save_e_h_patterns, save_3d_polar, save_summary
)


def main():
    substrate = SubstrateConfig()
    coax = CoaxFeedConfig()
    solver_cfg = SolverConfig(use_placeholder_kernel=True)
    freq_cfg = FrequencySweepConfig()
    target = np.array(NNSynthesisConfig().target_vector, dtype=np.float64)

    x0 = np.array([BASE_PATCH_X, BASE_PATCH_Y, BASE_SUB_X, BASE_SUB_Y, BASE_FEED_X, BASE_FEED_Y], dtype=np.float64)
    x_best, y_best, s_best = local_refine(clip_design_vector(x0), freq_cfg, substrate, coax, solver_cfg, target, n_steps=10, seed=1)
    geom_best, sub_best = x_to_geom_and_substrate(x_best, substrate)
    solver = PatchArrayMoMSolver(substrate, coax, solver_cfg)
    result = solver.solve(geom_best, make_frequency_grid(freq_cfg), substrate_override=sub_best)

    save_return_loss(result)
    save_vswr(result)
    save_directivity(result)
    save_radiation_pattern(result)
    save_e_h_patterns(result)
    save_3d_polar(result)
    save_summary(x_best, y_best, sub_best, coax, result, np.full(6, np.nan))

    print('Quick aligned 2.4 GHz single FR4 patch synthesis complete.')
    print('Saved: return_loss.png, vswr.png, directivity.png, radiation_pattern.png, e_h_field_patterns.png, polar_3d.png, synthesis_summary.txt')
    plt.close('all')


if __name__ == '__main__':
    main()
