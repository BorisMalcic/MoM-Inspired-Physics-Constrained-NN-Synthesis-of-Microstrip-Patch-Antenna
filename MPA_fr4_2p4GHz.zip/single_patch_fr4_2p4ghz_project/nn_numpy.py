import math
from typing import List

import numpy as np


class StandardScalerNP:
    def __init__(self):
        self.mu = None
        self.sigma = None

    def fit(self, x: np.ndarray):
        self.mu = x.mean(axis=0, keepdims=True)
        self.sigma = x.std(axis=0, keepdims=True) + 1e-8
        return self

    def transform(self, x: np.ndarray) -> np.ndarray:
        return (x - self.mu) / self.sigma

    def inverse_transform(self, x: np.ndarray) -> np.ndarray:
        return x * self.sigma + self.mu


def relu(x: np.ndarray) -> np.ndarray:
    return np.maximum(x, 0.0)


def relu_grad(x: np.ndarray) -> np.ndarray:
    return (x > 0.0).astype(np.float64)


class MLPRegressorNP:
    def __init__(self, in_dim: int, out_dim: int, hidden: int = 64, depth: int = 3, seed: int = 42):
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.hidden = hidden
        self.depth = depth
        self.rng = np.random.default_rng(seed)
        self.weights: List[np.ndarray] = []
        self.biases: List[np.ndarray] = []
        self.training_history = {'epoch': [], 'train_loss': [], 'val_loss': []}
        self._init_params()

    def _init_params(self):
        dims = [self.in_dim] + [self.hidden] * self.depth + [self.out_dim]
        self.weights = []
        self.biases = []
        for din, dout in zip(dims[:-1], dims[1:]):
            scale = math.sqrt(2.0 / max(din, 1))
            self.weights.append(self.rng.normal(0.0, scale, size=(din, dout)))
            self.biases.append(np.zeros((1, dout), dtype=np.float64))

    def forward(self, x: np.ndarray):
        acts = [x]
        pre = []
        a = x
        for i in range(len(self.weights) - 1):
            z = a @ self.weights[i] + self.biases[i]
            pre.append(z)
            a = relu(z)
            acts.append(a)
        z = a @ self.weights[-1] + self.biases[-1]
        pre.append(z)
        acts.append(z)
        return z, acts, pre

    def predict(self, x: np.ndarray) -> np.ndarray:
        y, _, _ = self.forward(x)
        return y

    def fit(self, x_train, y_train, x_val, y_val, epochs=80, batch_size=16, lr=1e-3, patience=18):
        n = len(x_train)
        best_val = float('inf')
        best_w = [w.copy() for w in self.weights]
        best_b = [b.copy() for b in self.biases]
        stale = 0
        for epoch in range(epochs):
            perm = self.rng.permutation(n)
            xt = x_train[perm]
            yt = y_train[perm]
            total = 0.0
            for s in range(0, n, batch_size):
                xb = xt[s:s + batch_size]
                yb = yt[s:s + batch_size]
                pred, acts, pre = self.forward(xb)
                diff = pred - yb
                loss = np.mean(diff ** 2)
                total += loss * len(xb)
                grad = (2.0 / max(len(xb), 1)) * diff
                gw = [np.zeros_like(w) for w in self.weights]
                gb = [np.zeros_like(b) for b in self.biases]
                gw[-1] = acts[-2].T @ grad
                gb[-1] = np.sum(grad, axis=0, keepdims=True)
                delta = grad @ self.weights[-1].T
                for layer in range(len(self.weights) - 2, -1, -1):
                    delta = delta * relu_grad(pre[layer])
                    gw[layer] = acts[layer].T @ delta
                    gb[layer] = np.sum(delta, axis=0, keepdims=True)
                    if layer > 0:
                        delta = delta @ self.weights[layer].T
                for i in range(len(self.weights)):
                    self.weights[i] -= lr * gw[i]
                    self.biases[i] -= lr * gb[i]
            train_loss = total / n
            val_loss = float(np.mean((self.predict(x_val) - y_val) ** 2))
            self.training_history['epoch'].append(epoch)
            self.training_history['train_loss'].append(train_loss)
            self.training_history['val_loss'].append(val_loss)
            if val_loss < best_val:
                best_val = val_loss
                best_w = [w.copy() for w in self.weights]
                best_b = [b.copy() for b in self.biases]
                stale = 0
            else:
                stale += 1
            if epoch % 10 == 0 or epoch == epochs - 1:
                print(f'epoch={epoch:03d} train_loss={train_loss:.6f} val_loss={val_loss:.6f}')
            if stale >= patience:
                print(f'early_stop epoch={epoch:03d} best_val={best_val:.6f}')
                break
        self.weights = best_w
        self.biases = best_b
        return self
