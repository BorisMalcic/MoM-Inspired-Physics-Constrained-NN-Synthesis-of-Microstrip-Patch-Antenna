from train_and_synthesize import main

if __name__ == '__main__':
    main()
