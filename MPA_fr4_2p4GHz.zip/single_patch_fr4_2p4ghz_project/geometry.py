from dataclasses import dataclass
from typing import List, Tuple

from config import ArrayGeometryConfig, SolverConfig, SubstrateConfig


@dataclass
class Cell:
    x0: float
    x1: float
    y0: float
    y1: float
    patch_ix: int
    patch_iy: int
    cell_ix: int
    cell_iy: int

    @property
    def xc(self) -> float:
        return 0.5 * (self.x0 + self.x1)

    @property
    def yc(self) -> float:
        return 0.5 * (self.y0 + self.y1)

    @property
    def area(self) -> float:
        return (self.x1 - self.x0) * (self.y1 - self.y0)


@dataclass
class PatchArrayMesh:
    cells: List[Cell]
    patch_boxes: List[Tuple[float, float, float, float, int, int]]


_WARNED = False


def build_patch_array_mesh(geom: ArrayGeometryConfig, substrate: SubstrateConfig, solver_cfg: SolverConfig) -> PatchArrayMesh:
    global _WARNED
    cells: List[Cell] = []
    patch_boxes: List[Tuple[float, float, float, float, int, int]] = []

    total_span_x = (geom.nx_elements - 1) * geom.pitch_x_m
    total_span_y = (geom.ny_elements - 1) * geom.pitch_y_m

    x_centers = [ix * geom.pitch_x_m - 0.5 * total_span_x for ix in range(geom.nx_elements)]
    y_centers = [iy * geom.pitch_y_m - 0.5 * total_span_y for iy in range(geom.ny_elements)]

    if solver_cfg.warn_on_patch_overlap and not _WARNED:
        if total_span_x + geom.patch_x_m > substrate.size_x_m or total_span_y + geom.patch_y_m > substrate.size_y_m:
            print('WARNING: requested patch footprint exceeds the nominal substrate size in at least one direction.')
        _WARNED = True

    dx = geom.patch_x_m / geom.nx_per_patch
    dy = geom.patch_y_m / geom.ny_per_patch

    for pix, xc in enumerate(x_centers):
        for piy, yc in enumerate(y_centers):
            x0_patch = xc - 0.5 * geom.patch_x_m
            x1_patch = xc + 0.5 * geom.patch_x_m
            y0_patch = yc - 0.5 * geom.patch_y_m
            y1_patch = yc + 0.5 * geom.patch_y_m
            patch_boxes.append((x0_patch, x1_patch, y0_patch, y1_patch, pix, piy))

            for cix in range(geom.nx_per_patch):
                for ciy in range(geom.ny_per_patch):
                    x0 = x0_patch + cix * dx
                    x1 = x0 + dx
                    y0 = y0_patch + ciy * dy
                    y1 = y0 + dy
                    cells.append(Cell(x0, x1, y0, y1, pix, piy, cix, ciy))

    return PatchArrayMesh(cells=cells, patch_boxes=patch_boxes)
