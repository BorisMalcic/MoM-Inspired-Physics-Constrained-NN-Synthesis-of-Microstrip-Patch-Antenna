from dataclasses import dataclass
from typing import Tuple
import math

C0 = 299_792_458.0


def effective_eps(eps_r: float, h_m: float, width_m: float) -> float:
    width_m = max(width_m, 1e-9)
    return 0.5 * (eps_r + 1.0) + 0.5 * (eps_r - 1.0) * (1.0 + 12.0 * h_m / width_m) ** -0.5


def fringing_delta_L(h_m: float, eps_eff: float, width_m: float) -> float:
    wh = width_m / max(h_m, 1e-12)
    num = (eps_eff + 0.3) * (wh + 0.264)
    den = (eps_eff - 0.258) * (wh + 0.8)
    return 0.412 * h_m * num / max(den, 1e-12)


def patch_width_guess(freq_hz: float, eps_r: float) -> float:
    return C0 / (2.0 * freq_hz) * math.sqrt(2.0 / (eps_r + 1.0))


def patch_length_guess(freq_hz: float, eps_r: float, h_m: float, width_m: float) -> float:
    eps_eff = effective_eps(eps_r, h_m, width_m)
    dL = fringing_delta_L(h_m, eps_eff, width_m)
    return C0 / (2.0 * freq_hz * math.sqrt(eps_eff)) - 2.0 * dL


BASE_FREQ = 2.4e9
BASE_SUB_H = 1.6e-3
BASE_EPS_R = 4.4
BASE_PATCH_Y = patch_width_guess(BASE_FREQ, BASE_EPS_R)
BASE_PATCH_X = patch_length_guess(BASE_FREQ, BASE_EPS_R, BASE_SUB_H, BASE_PATCH_Y)


@dataclass
class SubstrateConfig:
    eps_r: float = 4.4
    eps_eff_proxy: float = 3.9
    loss_tan: float = 0.02
    thickness_m: float = BASE_SUB_H
    size_x_m: float = 60.0e-3
    size_y_m: float = 60.0e-3
    auto_margin_m: float = 10.0e-3


@dataclass
class CoaxFeedConfig:
    pin_height_m: float = BASE_SUB_H
    pin_radius_m: float = 0.35e-3
    outer_radius_m: float = 1.20e-3
    port_impedance_ohm: float = 50.0


@dataclass
class ArrayGeometryConfig:
    nx_elements: int = 1
    ny_elements: int = 1
    center_freq_hz: float = BASE_FREQ
    patch_x_m: float = BASE_PATCH_X
    patch_y_m: float = BASE_PATCH_Y
    pitch_x_m: float = BASE_PATCH_X
    pitch_y_m: float = BASE_PATCH_Y
    nx_per_patch: int = 3
    ny_per_patch: int = 4
    feed_x_offset_m: float = 0.18 * BASE_PATCH_X
    feed_y_offset_m: float = 0.0

    @property
    def gap_x_m(self) -> float:
        return self.pitch_x_m - self.patch_x_m

    @property
    def gap_y_m(self) -> float:
        return self.pitch_y_m - self.patch_y_m


@dataclass
class FrequencySweepConfig:
    f_start_hz: float = 2.3e9
    f_stop_hz: float = 2.5e9
    n_points: int = 9


@dataclass
class SolverConfig:
    use_placeholder_kernel: bool = True
    regularization_ohm: float = 2e-2
    reference_impedance_ohm: float = 50.0
    warn_on_patch_overlap: bool = True
    corporate_feed_surrogate: bool = False


@dataclass
class NNSynthesisConfig:
    n_samples: int = 24
    seed: int = 7
    hidden: int = 128
    depth: int = 3
    epochs: int = 220
    batch_size: int = 4
    lr: float = 5e-4
    patience: int = 100
    # [f_res_GHz, S11@2.4GHz_dB, VSWR@2.4GHz, directivity_dBi, hpbw_deg, scan_deg]
    target_vector: Tuple[float, float, float, float, float, float] = (2.4, -14.0, 1.45, 6.5, 82.0, 0.0)
